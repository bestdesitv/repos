import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import subprocess
import urllib2,urllib
import re
import addon
import datetime
import time
import extract

VERSION = "1.6.5"
PATH = "BDTV MAINTENANCE"            
UATRACK="UA-38554991-1"   


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='https://dl.dropboxusercontent.com/u/88819516/bdtvmaintenance/'
baseone='https://dl.dropboxusercontent.com/u/138808030/xbmc/'

aftsq7='http://www.allfreetv.square7.ch/maint/'
bdtvpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
bdtvhomepath = xbmc.translatePath(os.path.join('special://home/', ''))
bdtvintsetup=os.path.join(bdtvpath, 'intdata')
bdtvrepo=os.path.join(bdtvpath, 'repository.bdtv')
hubrepo=os.path.join(bdtvpath, 'repository.bdtv')
mikey=os.path.join(bdtvpath, 'repository.xbmchub')
ADDON=xbmcaddon.Addon(id='plugin.video.hubmaintenance')
boxbackupzip=ADDON.getSetting('boxbackupzip')+'.zip'
dropboxnumber=ADDON.getSetting('boxnumber')
boxuserdata='https://dl.dropboxusercontent.com/u/%s/%s'%(dropboxnumber,boxbackupzip)
linux_download=ADDON.getSetting('download_linux')
wallpaper_download=ADDON.getSetting('download_wallpaper')
hd_wallurl='http://www.hdwallpapers.in'
wallurl='http://wallpaperswide.com'
thumbnailPath = xbmc.translatePath('special://thumbnails');
databasePath = xbmc.translatePath('special://database')

if ADDON.getSetting('visitor_ga')=='':
    from random import randint
    ADDON.setSetting('visitor_ga',str(randint(0, 0x7fffffff)))


if os.path.exists(mikey)==True: 
    for root, dirs, files in os.walk(mikey):
        for f in files:
            os.unlink(os.path.join(root, f))
        for d in dirs:
            shutil.rmtree(os.path.join(root, d))
    os.rmdir(mikey)


def DownloaderClass(url,dest, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create("BDTV...Maintenance","Downloading, Installing or Setting up",'')

    if useReq:
        import urllib2
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled(): 
                raise Exception("Canceled")                
                dp.close()

            chunk = resp.read(size)
            if not chunk:            
                f.close()
                break

            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)       
    else:
	    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Canceled")
        dp.close()

    ############################################################        Remove Mikey        ###############################################################
try:  
    if os.path.exists(hubrepo)==False: 
        GA("Maintenance Install","repo setup")
        print '############################################################        INSTALL BDTV Repo        ###############################################################'
        url = 'https://dl.dropbox.com/s/uazala8pqownm3b/repo.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        if os.path.exists(path)==True: 
        
            lib=os.path.join(path, 'repo.zip')
            DownloaderClass(url,lib)
            addonfolder = xbmc.translatePath(os.path.join('special://home',''))
            time.sleep(5)
            extract.all(lib,addonfolder)
except:
    pass        
    

    ############################################################     BDTV Int Setup     ###############################################################
try:  
    if os.path.exists(bdtvhomepath)==False: 
        GA("Maintenance Install","Int Data setup")
        print '############################################################        INSTALL BDTV Repo        ###############################################################'
        url = 'https://dl.dropbox.com/s/uazala8pqownm3b/repo.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        if os.path.exists(path)==True: 
        
            lib=os.path.join(path, 'repo.zip')
            DownloaderClass(url,lib)
            addonfolder = xbmc.translatePath(os.path.join('special://home',''))
            time.sleep(5)
            extract.all(lib,addonfolder)
except:
    pass        
    



def CATEGORIES():
#        dialog = xbmcgui.Dialog()
#        ok=dialog.ok('BDTV Box. Custom built best streaming box!!!', 'READ DISCRIPTION AT RIGHT SIDE INFO WINDOW. IF DONT', 'SEE INFO WINDOW, RIGHT CLICK ON REMOTE AND CHANGE','THE VIEW TO "MEDIA INFO".   **  bdtvbox@gmail.com  **')
        #addDir("How To Video's",howto,13,base+'images/VideoGuides.jpg',base+'images/fanart/gettingstarted.jpg','Safely delete all cache from plugins')
        addDir('1. Updates/Fixs/New apps within BDTV','https://dl.dropbox.com/s/jxjb58o0dy3th6x/customUPDATES.txt',1002,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix MENU')
        if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
            addDir('2. Exclusive Android Apps by ALLfree.TV','https://dl.dropbox.com/s/bhcauxi2wchch5p/apks.txt',1037,base+'images/AndroidTV.jpg',base+'images/AndroidTV.jpg','Check if your device is NEXUS Player or Amazon Fire TV')
        addDir('3. Maintenance [COLOR red]Check every 6 months[/COLOR]','url',9,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Safely delete all cache from plugins')
        addDir('ADD-ONS.  Special Manual Updates','url',50,base+'repoinstalls/xbmcbdtvrepo/icon.png',base+'repoinstalls/xbmcbdtvrepo/fanart.jpg','Addon Manual Install/Patches/fixes')
        #addDir('Install Si02 For Eden','https://dl.dropboxusercontent.com/u/88819516/bdtvmaintenance/info/skin.txt',16,base+'images/si02.png',base+'images/fanart/expert.jpg','Adding Your Favourite Tweaks')
#        addDir('Add-On FIXER','url',10,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix MENU')
        if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
            addDir('Buffer settings','https://dl.dropbox.com/s/qkr0eq3flacq47v/1GBAdvSettings.xml',5,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Add advanced settings to sort your buffering if you have issues')
            addDir('BDTV Update Check/Install','https://dl.dropbox.com/s/ezcczzcp9ppcu6t/android-update.txt',1035,base+'images/AndroidTV.jpg',base+'images/AndroidTV.jpg','Check if your device is NEXUS Player or Amazon Fire TV')
            addDir('Nexus and FireTV Remote Setup','url',68,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Different set of configration for remote')
            addDir('[COLOR red]Restore System Settings[/COLOR]','URL',1001,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Restore BDTV System Settings like backgroud etc.')
#        addDir('Tweaks','url',11,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Adding Your Favourite Tweaks')
#        addDir("Wallpaper Downloads",howto,48,base+'images/wallpapers.jpg',base+'images/fanart/gettingstarted.jpg','Safely delete all cache from plugins')
#        if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
#             addDir('Configration 1 for[COLOR green]BDTV on Fire TV[/COLOR]','url',68,aftsq7+'remotes/amazon_firetvstick_remote.jpg',aftsq7+'remotes/amazon_firetvstick_remote.jpg','This will more functions to all remotes, see icon for more info.')
        if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.android'):
#           addDir('[COLOR red]TvOnDesiZONE Major UPDATE[/COLOR]','url',4,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Fix empty list in TV on Desi Zone, Desi Tashan, Desi Ronak. You need to refersh Data from Addon setting by pressing MENU on addon at video addon list."')
            addDir('Set HomeScreen Shortcuts','url',120,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Set Shortcuts at Home Screen')
            addDir('Remotes for BDTV','url',60,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Set the different remotes for BDTV Boxs')
            addDir('[COLOR gold]MODEL: X-M3 & X-M1 FIRMWARE UPDATES[/COLOR]','url',500,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its X-M1. X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')
#            addDir('[COLOR gold]MODEL: X-M1 FIRMWARE UPDATES[/COLOR]','https://dl.dropboxusercontent.com/u/90916090/textfiles/firmware.txt',33,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its model X-M1.   X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')
            addDir('X-M1 & X-M3 system settings reset','url',112,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','X-M1 system settings reset')
#            addDir('Set HomeScreen Shortcuts','url',120,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Set Shortcuts at Home Screen')
        addDir('EXPERT LEVEL','url',900,base+'images/donttry.jpg',base+'images/images/donttry.jpg','ONLY DO THIS STEP IF ASK BY BDTV SERVICE CALL')
        addDir('Email your LogFile for problem fixing','url',15,base+'images/logger.png',base+'images/fanart/expert.jpg','email your logfile to diagnose your box problem')
        addDir('Need Help??','url',2000,base+'images/help.jpg',base+'images/fanart/expert.jpg','BDTV CONTACT INFORMATION')
        setView('movies', 'MAIN')

def linuxXm3(url):
        dialog = xbmcgui.Dialog()
        ok=dialog.ok('Please finish all following 4 STEPS', 'It takes me 200+hrs extra to make this update for existing', 'customers. If you want me to keep your boxes always','updated. Please recomend BDTV Box. bdtvbox@gmail.com')
        #addDir('Please follow the caption carefully or read at www.ALLfree.TV','url',501,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable X-M1, X-M3 ORIGINAL SMALL WHITE AND LOGITECH HARMONY 200 and 300')
        #addDir('STEP 1 POWER OFF SYSTEM then take microSD card out and any other USB device, power on without sd card','url',502,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable X-M1, X-M3 ORIGINAL SMALL WHITE AND LOGITECH HARMONY 200 and 300')
        addDir('STEP-0, Download BACKUP FIRMWARE','https://dl.dropbox.com/s/8dr6f3jd22a3f4r/fm-xios-ds-bk.txt',37,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('[COLOR gold]Download BACKUP FIRMWARE up before Step-1[/COLOR]','url',507,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 4in1 RCA Universal Remote MODEL RCRN04GR')
        addDir('STEP-1, CLICK HERE, CHOOSE X-M3 MODEL THEN LATEST FIRMWARE','https://dl.dropbox.com/s/97k6299ohsj6571/fm-xios-ds.txt',33,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('[COLOR gold]CHOOSE NO ON ANY ADDON BROKEN POPUP MSG for day or two, REBOOT 3 times MANUALY AFTER every HOURS[/COLOR]','url',507,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 4in1 RCA Universal Remote MODEL RCRN04GR')
        addDir('STEP-2,  CLICK HERE. BOX WILL REBOOT','url',901,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('[COLOR gold]CHOOSE NO ON ANY ADDON BROKEN POPUP MSG for day or two, REBOOT 3 times MANUALY AFTER every HOURS[/COLOR]','url',507,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 4in1 RCA Universal Remote MODEL RCRN04GR')
#        addDir('STEP-2, CLICK HERE. BOX WILL REBOOT','url',504,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('STEP-3, Add-Ons SETUP (OPTIONAL)','https://dl.dropbox.com/s/kf9dsybq06gl8aj/datarestore.txt',505,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('STEP-4, CLICK HERE, WILL TAKE 30-60min AFTER AUTO-REBOOT','url',506,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
        addDir('[COLOR gold]CHOOSE NO ON ANY ADDON BROKEN POPUP MSG for day or two, REBOOT 3 times MANUALY AFTER every HOURS[/COLOR]','url',507,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 4in1 RCA Universal Remote MODEL RCRN04GR')
#        addDir('STEP 7','url',508,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable 5in1 Silver Color Universal Remote MODEL RM-V301')
#        addDir('Reboot to FIRMWARE update screen','url',509,base+'images/alllinux.jpg',base+'images/fanart/expert.jpg','REBOOT RECOVERY WITHOUT PRESSING PIN HOLE BOTTON')
        setView('movies', 'SUB')
        GA("None","Firmware")

def bdtvsetup(url):
        dialog = xbmcgui.Dialog()
        ok=dialog.ok('DO NOT TRY YOURSELF', 'DO NOT TRY FOLLOWING STEPS', 'IF NOT RECOMENDED BY BDTV SERVICE CALL')
        if xbmc.getCondVisibility('system.platform.linux'):
             addDir('LINKS','url',901,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
             addDir('First Setup','url',906,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','This will enable 3in1 PHILIPS Universal Remote MODEL SRP1003/27')
             addDir('Force Reboot','url',902,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','REBOOT')
             addDir('Reboot Recovery','url',509,base+'images/alllinux.jpg',base+'images/fanart/expert.jpg','REBOOT RECOVERY')
             addDir('Shrink screen fix','url',600,base+'images/alllinux.jpg',base+'images/fanart/expert.jpg','Fix if display srink to quater size')
        addDir('BDTV Super Installer','url',18,base+'images/fusion.jpg',base+'images/fanart/expert.jpg','BDTV Super Installer')
        addDir('Install BDTV Repo','url',21,base+'repoinstalls/xbmcbdtvrepo/icon.png',base+'repoinstalls/xbmcbdtvrepo/fanart.jpg','Install BDTV Repositories')
        addDir('Install Adult Addons','url',101,base+'repoinstalls/xbmcbdtvrepo/icon.png',base+'repoinstalls/xbmcbdtvrepo/fanart.jpg','Install Adult Addons')
        addDir('Remove Adult Addons','url',102,base+'repoinstalls/xbmcbdtvrepo/icon.png',base+'repoinstalls/xbmcbdtvrepo/fanart.jpg','Remove Adult Addons')
        setView('movies', 'SUB')
        GA("None","Setup")

def remotes(url):
        addDir('Click me to add Add more functions on remote [COLOR green]July 08, 2015[/COLOR]','url',67,aftsq7+'remotes/keyboard.jpg',aftsq7+'remotes/keyboard.jpg','This will more functions to all remotes, see icon for more info.')
        if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.android'):
             addDir('X-M1, X-M3 ORIGINAL SMALL WHITE AND LOGITECH HARMONY 200 and 300','url',62,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','This will enable X-M1, X-M3 ORIGINAL SMALL WHITE AND LOGITECH HARMONY 200 and 300')
             addDir('ZENITH JP505','url',66,'http://i.imgur.com/cwO9742.png','http://i.imgur.com/cwO9742.png','This will enable ZENITH PJ505 Universal Remote')
             addDir('PHILIPS SRP1003/27','url',63,'http://i.imgur.com/6IDJfKk.jpg?1','http://i.imgur.com/6IDJfKk.jpg?1','This will enable PHILIPS SRP1003/27 3in1 Universal Remote')
             addDir('PHILIPS SRP2006/27','url',65,'http://i.imgur.com/HC3TXNy.jpg?1','http://i.imgur.com/HC3TXNy.jpg?1','This will enable PHILIPS SRP2006/27 6in1 Universal Remote MODEL SRP2006/27')
             addDir('RCA RCRN04GR 4in1','url',64,'http://www.twinint.com/catalog/images/P/RCRN04GR_PKG_HO..JPG','http://www.twinint.com/catalog/images/P/RCRN04GR_PKG_HO..JPG','This will enable 4in1 RCA Universal Remote MODEL RCRN04GR')
             addDir('5in1 Silver Color MODEL RM-V301','url',61,'http://i.imgur.com/QuIdgR3.png','http://i.imgur.com/QuIdgR3.png','This will enable 5in1 Silver Color Universal Remote MODEL RM-V301')
        setView('movies', 'SUB')
        GA("None","Remotes")

def addoninstallpatch(url):
        addDir('Delete all SportsDevil Custom Modules','url',905,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Remove all custom modules and then install only you like below')
        addDir('SportsDevil Custom Modules, [COLOR yellow]do regularly[/COLOR]','https://dl.dropbox.com/s/oyzdwqkzhu494ru/sp-custom.txt',51,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Install SportsDevil Custom Modules, you can remove unwanted custom modules by clicking MENU on them')
        #addDir('SportsDevil Main Modules','url',52,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Install SportsDevil Main Modules like LiveSports, TV etc. You can also add these to Favorites')
        addDir('Updated live list for Livestreams App','https://dl.dropbox.com/s/u044osl2jajr3j1/livelists.txt',70,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','It will add new/updated live servers in Livestreams app')
        addDir('Addon Categories Setup','url',53,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Run it, restart and go to video>Add-ons>Categories Addon to get your Addons shorted in Categories')
        if xbmc.getCondVisibility('system.platform.linux'):
             #addDir('Enable Geo-Restricted Content','url',54,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Run it and restart to watch HULU, BBC iPlayer UK and many more GEO-RESTRICTED Content for FREE without paying hundreds of dollars every month.')
             addDir('Restore Country Content','url',55,base+'images/tweaks.jpg',base+'images/fanart/beginners.jpg','Run it and restart if some of your Country content stop working e.g. CBC, Global, HGTV etc. in Canada, You can enable geo-restricted content anytime again.')
             addDir('Enable ADULT at Sportsdevil [COLOR red](Yamgo TV)[/COLOR] and [COLOR red]Dailymotion[/COLOR] Addons',base+'',56,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','It will Enable Adult content in Dailymotion. Manual Install more Adult content addons from BDTV Installer')
             addDir('Remove ADULT at Sportsdevil [COLOR green](Yamgo TV)[/COLOR] and [COLOR green]Dailymotion[/COLOR] Addons',base+'',57,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','It will remove Adult content from Dailymotion. To install other Adult Content addons see guide at Web Viewer')
        setView('movies', 'SUB')
        GA("None","Addons Patch")

		
def popup(name):
         GA("None","Need Help")
         xbmcgui.Dialog().ok('BDTV Information','BDTVBOX@GMAIL.COM   +1 780 802 9264','[COLOR yellow][B]WWW.BDTBOX.BLOGSPOT.COM   ALLfree.TV[/B][/COLOR]','For Support Please Visit Us')

def maintenance(url):
        addDir('1. Delete Packages. [COLOR red]Do it every couple of months[/COLOR]','url',2,base+'images/maintenance.jpg',base+'images/fanart/advanced.jpg','Delete all you old zipped packages very safe but you wont be able to roll back')
        if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
            addDir('2. Refresh Thumbnails [COLOR red]Do it every six months[/COLOR]','url',111,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Delete stale thumbnails and textures')
        #addDir('Download All Repos','https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/allrepos.zip',35,base+'repoinstalls/xbmchubrepo/icon.png',base+'repoinstalls/xbmchubrepo/fanart.jpg','Install BDTV REPOSITORIES')
        #addDir("Download All UK Plugins/Repos",'https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/uk.zip',35,base+'repoinstalls/xbmchubrepo/icon.png',base+'repoinstalls/xbmchubrepo/fanart.jpg','Install All Uk Plugins and Repos')
        #if ADDON.getSetting('userdata') == 'true': 
            #addDir('Restore Userdata',boxuserdata,23,base+'images/restore.png',base+'repoinstalls/xbmcbdtvrepo/fanart.jpg','Restore all your personal userdata settings.xml')
        #addDir('Remove Addons','plugin.',25,base+'images/recycle.png',base+'images/fanart/beginners.jpg','Safely Remove Unwanted plugins')
        addDir('Delete My Cache','url',3,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Safely delete all cache from plugins')
        addDir('Delete Crash Logs','url',1,base+'images/maintenance.jpg',base+'images/fanart/advanced.jpg','Delete all your old crash logs')
        addDir('Remove Bad Addons Data. (Only on customer service request)','plugin',36,base+'images/recycle.png',base+'images/fanart/beginners.jpg','Safely Remove Addon Data File giving error')
        addDir('Remove Repos (Only on customer service request)','repository.',25,base+'images/recycle.png',base+'images/fanart/beginners.jpg','Safely Remove Unwanted Repositories')
        addDir('Remove Skins (Only on customer service request)','skin.',25,base+'images/recycle.png',base+'images/fanart/beginners.jpg','Safely Remove Unwanted Skins')
        if xbmc.getCondVisibility('system.platform.ATV2')or xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.osx'):
            addDir('Update Lib File','url',12,base+'images/maintenance.jpg',base+'images/fanart/expert.jpg','Update you lib file for rtmp live streams')
        if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
            addDir('(For Nexus Player only and optional)Update Lib File','url',12,base+'images/maintenance.jpg',base+'images/fanart/expert.jpg','Update you lib file for rtmp live streams')
        setView('movies', 'SUB')
        
def fixesdir(url):
        #addDir('Hulu Fix','https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/fix/script.module.cryptopy.zip',31,'https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/images/hulu.png',base+'images/fanart/advanced.jpg','Fix For Hulu')
        #addDir('1Channel url error Fix','url',31,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This to fix 1channel Connection Failed: Failed to connect to url issue')
        addDir('BDTV World Live FIX','url',1000,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix Genesis update')
        addDir('CANADA PACK Inst','url',39,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Install Canadian APPS like Slice Canada, Showcase, ET Canada etc')
        addDir('Genesis FIX','url',1039,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix Genesis update')
        addDir('AfterShick & DesiZone FIX','url',30,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Getting error on TVonDesiZONE, try it')
        addDir('1Galaxy FIX','url',27,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix MENU')
        if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.android'):
            addDir('1Channel error fix','url',20,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Getting error on 1Channel, try it')
            addDir('Fix missing icons. Needs reboot',base+'',100,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Fix For YouTube')
        #addDir('1Channel Subtitles Fix','https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/fix/1channelfix.txt',27,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Use This To Fix Subtitles Not Working')
        if 'DatabaseError: database disk image is malformed' in oldlogfile() or 'DatabaseError: database disk image is malformed' in logfile():
            addDir('1Channel.db Issues Fix ','url',8,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Only Use this if you Know that it is your 1Channel.db is malformed \n\nIF YOU GET THIS MESSAGE IN YOUR LOG \n plugin.video.1channel/default.py \n"DatabaseError: database disk image is malformed"\nThen use this fix')
            addDir('1Channel/Icefilms Meta_Cache Fix','url',7,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Only Use this if you Know that it is your meta_cache video_cache.db is malformed \n\nIF YOU GET THIS MESSAGE IN YOUR LOG \nlib/metahandler/metahandlers.py \n"DatabaseError: database disk image is malformed"\n\n Then use this fix')
        #addDir('Extend Captcha Times','url',24,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','If you can never see the captchas for long enough please install this it will give you 5 seconds to read the captcha before the keyboard pops up')
        #addDir('Fix Slow Gui Issues','url',28,base+'images/maintenance.jpg',base+'images/fanart/beginners.jpg','Fix Slow GUI (Not Necessarily Going To Work For All!!)')
        if xbmc.getCondVisibility('system.platform.ATV2'):
            addDir('1Channel error fix','url',19,base+'images/fixes.jpg',base+'images/fanart/advanced.jpg','Getting error on 1Channel, try it')
        setView('movies', 'SUB')
def tweaksdir(url):
        if xbmc.getCondVisibility('system.platform.ATV2'):
             addDir('Confluence 7 Shortcut Icons','url',40,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Add 7 Shoutcut Icons To Your Home Menu For Video')
        #addDir('Add Tuxens Advanced XML',base+'tweaks/tuxen.xml',5,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Add advanced xml to sort your buffering if you have issues')
        #addDir('Add Mikey1234 Advanced XML',base+'tweaks/mikeys.xml',5,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Add advanced xml to sort your buffering if you have issues')
        #addDir('Buffer settings for [COLOR red]Apple TV-1[/COLOR]',base+'tweaks/0cache.xml',5,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Add advanced settings to sort your buffering if you have issues')
        #addDir('Check What XML You Are Using','url',29,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Check what advancedsettings.xml your are using')
        #addDir('Remove buffer settings','url',14,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','Remove buffer settings, if they give problems')
        if xbmc.getCondVisibility('system.platform.ATV2'):
             addDir('Add Skip Forward/Back 10 Mins',base+'tweaks/joystick.AppleRemote.xml',6,base+'images/tweaks.jpg',base+'images/fanart/expert.jpg','ATV2 must have so you can push up or down to skip 10 minutes back or forward')
        setView('movies', 'SUB')
        
def wallpaper_catergories():
        addDir("wallpaperswide.com",howto,44,base+'images/wallpaperwide.png',base+'images/fanart/gettingstarted.jpg','Safely delete all cache from plugins')
        addDir("hdwallpapers.in",howto,49,'http://www.hdwallpapers.in/templates/custom/images/logo.png',base+'images/fanart/gettingstarted.jpg','Safely delete all cache from plugins')
        

		
		############################################################        1Channel ATV 1 2 fix          ###############################################################  
  
def non64Play(url,name):
    if url.startswith('plugin://'):
        xbmc.executebuiltin("xbmc.PlayMedia("+url+")")
        return
    xbmc.Player().play(url)
	
    return
	
def showPIC(url):
    xbmc.executebuiltin('ShowPicture(%s)'%(url))
    return

def showSLIDE(url):#SlideShow(dir [,recursive, [not]random])
    xbmc.executebuiltin('SlideShow(%s)'%(url))
    return

def runexe(url):#SlideShow(dir [,recursive, [not]random])
    xbmc.executebuiltin("ActivateWindow(10025," + url + ',return)')
#    xbmc.executebuiltin('ActivateWindow(%s)'%(url))
    return

def atv2channe1fix(url):
    GA("Fixes","AllUSERfix")
    print '############################################################       1Channel ATV 1 2 fix          ###############################################################'
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.1channel')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechrepopath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechrepo=os.path.join(onechrepopath, 'repository.bstrdsmkr')
    if os.path.exists(onechrepo)==True: 
        for root, dirs, files in os.walk(onechrepo):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechrepo)
                        
    else:
        pass
    onechpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onech=os.path.join(onechpath, 'plugin.video.1channel')
    if os.path.exists(onech)==True: 
        for root, dirs, files in os.walk(onech):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onech)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addon_data', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.genesisreborn')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.genesisreborn')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.genesisreborn.metadata')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.genesisreborn.artwork')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.module.genesisreborn')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addon_data', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.genesis')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.genesis')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.genesis.metadata')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.genesis.artwork')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.module.genesis')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addon_data', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.exodusredux')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.exodusredux')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'repository.exodusredux')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.exodusredux.metadata')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.exodusredux.artwork')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.module.exodusredux')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addon_data', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.exodus')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.exodus')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.exodus.metadata')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.exodus.artwork')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'script.module.exodus')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    commonpath = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.common.plugin.cache',''))
    common=os.path.join(commonpath, 'commoncache.db')
    if os.path.exists(common)==True: 

        os.remove(common)

    else:
        pass
    onechbasepath = xbmc.translatePath(os.path.join('special://home/userdata/Database',''))
    onechbase=os.path.join(onechbasepath, 'onechannelcache.db')
    if os.path.exists(onechbase)==True: 

        os.remove(onechbase)

    else:
        pass
    add15path = xbmc.translatePath(os.path.join('special://home/userdata/Database',''))
    add15=os.path.join(add15path, 'Addons15.db')
    if os.path.exists(add15)==True: 

        os.remove(add15)

    else:
        pass
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'inflate.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('CLICK OK TO EXIT!', "      OPEN BDTV back and ENJOY fixed/Updated/New Addons!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	


		############################################################        TvOnDesi Update          ###############################################################  
  
def atv2desifix(url):
    GA("Fixes","atv2 desiZONE UPDATE")
    print '############################################################       TvOnDesi Update          ###############################################################'
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.TVonDesiZone')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.tvondesizone')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.tvondesizonex')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.tvondesizonexl')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.aftershock')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.swadesi')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.aftershock')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.swadesi')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.TVonDesiZone')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.tvondesizone')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.tvondesizonex')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.tvondesizonexl')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.bdtv-desilive')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.bdtv-desilive')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    commonpath = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.common.plugin.cache',''))
    common=os.path.join(commonpath, 'commoncache.db')
    if os.path.exists(common)==True: 
    
        os.remove(common)
    
    else:
        pass
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'inflate.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('CLICK OK TO EXIT!', "      OPEN BDTV back and ENJOY Fixed/Updated/New Desi Addons!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	

	

		############################################################        Canada Pack          ###############################################################  
  
def canadapack(url):
    GA("Fixes","Canada pack")
    print '############################################################       Canada Pack          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'canadapack.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('CLICK OK TO REBOOT!', "Find Slice Canada, Showhome Canada and ET Canada etc under ALL Video Apps!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	

	

		############################################################        Canada Pack          ###############################################################  
  
def inflate(url):
    GA("Fixes","custom unzip")
    print '############################################################       Canada Pack          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'inflate.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('Yes for new, NO for fixs!', "you can choose NO for fixs/updates, Yes for new addons!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]+1-780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	

	

		############################################################        Root Pack          ###############################################################  
  
def ROOTinflate(url):
    GA("Fixes","Root unzip")
    print '############################################################       Canada Pack          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'inflate.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('/storage/emulated/0/',''))
        time.sleep(5)
        extract.all(lib,addonfolder)
        dialog = xbmcgui.Dialog()
        dialog.ok("[COLOR green]DONE![/COLOR]", "Data downloaded, proceed to next step as suggested/supposet.")


		############################################################    Android SETTINGS RESTORE    ###############################################################  
  
def AndSETUP():
    GA("Fixes","Android Restore")
    print '############################################################    Android SETTINGS RESTORE    ###############################################################'
    commonpath = xbmc.translatePath(os.path.join('special://home/userdata',''))
    common=os.path.join(commonpath, 'guisettings.xml')
    if os.path.exists(common)==True: 
    
        os.system("systemctl stop xbmc.service")
        os.remove(common)
        time.sleep(3)
    
    else:
        pass
    url = 'https://dl.dropbox.com/s/ddtvgsi6eyfkpzj/AndroidSETUP.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'AndroidSETUP.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR red]Don't click 'OK' [/COLOR][COLOR green]and please read below[/COLOR]", "Click HOME (O) button on remote, then go to settings, then Apps, then BDTV, then FORCE STOP it! If force stop option is not available, then step back and go to 'About' and 'Restart' and open BDTV! Take my picture to remeber :) . ENJOY!")
#    os.system("systemctl start xbmc.service")	

	

		############################################################        Genesis FIX          ###############################################################  
  
def genesisfix(url):
    GA("Fixes","Genesis FIX")
    print '############################################################       Genesis FIX          ###############################################################'
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.genesis')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.genesis')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'genesis-fix.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('CLICK OK TO REBOOT!', "      OPEN Genesis AFTER BOX RESTART. ENJOY!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	

	

		############################################################        World Live FIX          ###############################################################  
  
def worldlive(url):
    GA("Fixes","WorldLIVE FIX")
    print '############################################################       World Live FIX          ###############################################################'
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.bdtv-desilive')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    oneChpath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    oneCh=os.path.join(oneChpath, 'plugin.video.bdtv-desilive')
    if os.path.exists(oneCh)==True: 
        for root, dirs, files in os.walk(oneCh):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(oneCh)
                        
    else:
        pass
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 
    
        lib=os.path.join(path, 'desilive.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home',''))
        time.sleep(10)
        extract.all(lib,addonfolder)
    
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('CLICK OK TO REBOOT!', "      OPEN BDTV again and. ENJOY!", "     [COLOR red]If you enjoy BDTV Box, Please tell others about it.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       xbmc.executebuiltin("XBMC.Quit()")	

	

		############################################################        STANDARD CACHE          ###############################################################  
  
def deletecachefiles(url):
    GA("Maintenance","Delete Cache")
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete XBMC Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
    dialog = xbmcgui.Dialog()
    dialog.ok("BDTV TEAM", "       Thats It All Done Please Come Visit Again", "          [COLOR yellow]Brought To You ALLfree.TV[/COLOR]")
    
    
############################################################        PACKAGES          ###############################################################    
          
def DeletePackages(url):
    GA("Maintenance","Delete Packages")
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("ALLfree.TV", "       Thats It All Done Please Come Visit Again", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "Packages Wont Delete", "Sort It!!    Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
        
        
############################################################        DELETING CRASH LOGS          ###############################################################    
        
def DeleteCrashLogs(url):  
    print '############################################################       DELETING CRASH LOGS             ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Delete Old Crash Logs", '', "Do you want to delete them?"):
        path=loglocation()
        import glob
        for infile in glob.glob(os.path.join(path, 'xbmc_crashlog*.*')):
             File=infile
             print infile
             os.remove(infile)
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "Please Reboot XBMC To Take Effect !!", "Brought To You By www.ALLfree.TV or fb.com/AFTbox")
    GA('Maintenance','Deleting Crash Logs')
            

############################################################        ADVANCE XML          ###############################################################    
    
def advancexml(url,name):

    GA("Tweaks",name)
    print '############################################################       ADVANCE XML          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    advance=os.path.join(path, 'advancedsettings.xml')
    try:
        os.remove(advance)
        print '========= REMOVING    '+str(advance)+'    ====================================='
    except:
        pass
    link=OPEN_URL(url)
    a = open(advance,"w") 
    a.write(link)
    a.close()
    print '========= WRITING NEW    '+str(advance)+'    =========================='
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")

############################################################        CHECK ADVANCE XML          ###############################################################    
    
def checkadvancexml(url,name):
    print '############################################################       CHECK ADVANCE XML          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    advance=os.path.join(path, 'advancedsettings.xml')
    try:
        a=open(advance).read()
        if re.search('34603008',a,re.IGNORECASE):
            name='MIKEYS'
        if re.search('size>0</cache',a,re.IGNORECASE):
            name='0'
        if re.search('<network> <curlclienttimeout>',a,re.IGNORECASE):
            name='TUXENS'
    except:
        name="NO ADVANCED"
    GA("Tweaks","Check XML:"+name)
    dialog = xbmcgui.Dialog()
    dialog.ok("BDTV TEAM","[COLOR yellow]YOU HAVE[/COLOR] "+ name+"[COLOR yellow] SETTINGS SETUP[/COLOR]")
    
############################################################        DELETE ADVANCE XML          ###############################################################    
def deleteadvancexml(url):
    GA("Tweaks","Delete Advanced XML")
    print '############################################################       DELETING ADVANCE XML          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    advance=os.path.join(path, 'advancedsettings.xml')
    os.remove(advance)
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
    
############################################################        KEYMAPS          ###############################################################    
    
    
def joystick(url): 
    GA("Tweaks","Joystick")
    print '############################################################        KEYMAPS          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/userdata/keymaps',''))
    joystick=os.path.join(path, 'joystick.AppleRemote.xml')
    try:
        os.remove(joystick)
        print '========= REMOVING    '+str(joystick)+'     =========================='
    except:
        pass
    link=OPEN_URL(url)
    a = open(joystick,"w") 
    a.write(link)
    a.close()
    print '========= WRITING NEW    '+str(joystick)+'     =========================='
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
    
    
############################################################        CORRUPT META          ###############################################################    
    
def malformed(url):
    GA("Maintenance","Malformed META")
    dialog = xbmcgui.Dialog()
    if dialog.yesno("[B][COLOR red]WARNING !!![/B][/COLOR]", '[B]ARE YOU SURE YOU KNOW WHAT THIS DOES !?![/B]','', "[B][COLOR red]     AS YOU CANNOT GO BACK !!![/B][/COLOR]"):
        print '############################################################        CORRUPT META          ###############################################################'
        path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.module.metahandler/meta_cache',''))
        meta=os.path.join(path, 'video_cache.db')
        try:
            os.remove(meta)
            print '========= REMOVING  '+str(meta)+'     =========================='
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       CANT DELETE!!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
        print '========= WRITING NEW   '+str(meta)+'     =========================='
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "           REBOOT XBMC !!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
        
############################################################        1CHANNEL.DB CORRUPT         ###############################################################    
    
def onechanneldb(url):
    GA("Maintenance","Corrupt 1Channel.db")
    dialog = xbmcgui.Dialog()
    if dialog.yesno("[B][COLOR red]WARNING !!![/B][/COLOR]", '[B]ARE YOU SURE YOU KNOW WHAT THIS DOES !?![/B]','', "[B][COLOR red]     AS YOU CANNOT GO BACK !!![/B][/COLOR]"):
        print '############################################################        1CHANNEL.DB CORRUPT          ###############################################################'
        path = xbmc.translatePath(os.path.join('special://home/userdata/Database',''))
        onechanneldb=os.path.join(path, 'onechannelcache.db')
        try:
            os.remove(onechanneldb)
            print '========= REMOVING   '+str(onechanneldb)+'     =========================='
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       CANT DELETE!!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        print '========= WRITING NEW   '+str(onechanneldb)+'     =========================='
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "           REBOOT XBMC !!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
    
    
############################################################        LYB          ###############################################################    
    
def loglocation(): 
    versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
    if versionNumber < 12:
        if xbmc.getCondVisibility('system.platform.osx'):
            if xbmc.getCondVisibility('system.platform.atv2'):
                log_path = '/var/mobile/Library/Preferences'
            else:
                log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
        elif xbmc.getCondVisibility('system.platform.ios'):
            log_path = '/var/mobile/Library/Preferences'
        elif xbmc.getCondVisibility('system.platform.windows'):
            log_path = xbmc.translatePath('special://home')
            log = os.path.join(log_path, 'kodi.log')
        elif xbmc.getCondVisibility('system.platform.linux'):
            log_path = xbmc.translatePath('special://home/temp')
        else:
            log_path = xbmc.translatePath('special://logpath')
    elif versionNumber > 11:
        log_path = xbmc.translatePath('special://logpath')
        log = os.path.join(log_path, 'kodi.log')
    return log_path

def logfile(): 
    versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
    if versionNumber < 12:
        if xbmc.getCondVisibility('system.platform.osx'):
            if xbmc.getCondVisibility('system.platform.atv2'):
                log_path = '/var/mobile/Library/Preferences'
            else:
                log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
        elif xbmc.getCondVisibility('system.platform.ios'):
            log_path = '/var/mobile/Library/Preferences'
        elif xbmc.getCondVisibility('system.platform.windows'):
            log_path = xbmc.translatePath('special://home')
            log = os.path.join(log_path, 'xbmc.log')
        elif xbmc.getCondVisibility('system.platform.linux'):
            log_path = xbmc.translatePath('special://home/temp')
        else:
            log_path = xbmc.translatePath('special://logpath')
    elif versionNumber > 11:
        log_path = xbmc.translatePath('special://logpath')
    
    log = os.path.join(log_path, 'kodi.log')
    logfile=open(log, 'r').read()
    return logfile

def oldlogfile(): 
    versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
    if versionNumber < 12:
        if xbmc.getCondVisibility('system.platform.osx'):
            if xbmc.getCondVisibility('system.platform.atv2'):
                log_path = '/var/mobile/Library/Preferences'
            else:
                log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
        elif xbmc.getCondVisibility('system.platform.ios'):
            log_path = '/var/mobile/Library/Preferences'
        elif xbmc.getCondVisibility('system.platform.windows'):
            log_path = xbmc.translatePath('special://home')
            log = os.path.join(log_path, 'xbmc.log')
        elif xbmc.getCondVisibility('system.platform.linux'):
            log_path = xbmc.translatePath('special://home/temp')
        else:
            log_path = xbmc.translatePath('special://logpath')
    elif versionNumber > 11:
        log_path = xbmc.translatePath('special://logpath')
    
    log = os.path.join(log_path, 'kodi.old.log')
    logfile=open(log, 'r').read()
    return logfile
    
def lib(url): 
    GA("Maintenance","Update Lib")
    print '############################################################        LYB          ###############################################################'
    log_path=loglocation()
    log = os.path.join(log_path, 'kodi.log')
    logfile=open(log, 'r').read()
    if 'Windows' in logfile:
        match = re.compile('special://xbmc/ is mapped to: (.+?)\\XBMC').findall(logfile)

        path = xbmc.translatePath(os.path.join(match[0]+'XBMC\system\players\dvdplayer',''))
        lib=os.path.join(path, 'librtmp.dll')
        try:
            os.remove(lib)
        except:
            pass
        url = 'https://dl.dropbox.com/s/lki0269evgsu7ik/librtmp.dll'
        DownloaderClass(url,lib)
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        
    if 'Darwin OSX' in logfile:

        try:    
            match = re.compile('special://frameworks/ is mapped to: (.+?)Frameworks').findall(logfile)
            path = xbmc.translatePath(os.path.join(match[0]+'Frameworks',''))
            lib=os.path.join(path, 'librtmp.0.dylib')
            try:
                os.remove(lib)
            except:
                pass
            url = 'https://dl.dropbox.com/s/d9mywzxpsqt102c/librtmp.0.dylib'
            DownloaderClass(url,lib)
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        except: 
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       CANT UPDATE YOUR LIB FILE SORRY!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        
    if 'Darwin iOS' in logfile:

        try:    
            match = re.compile('special://frameworks/ is mapped to: (.+?)Frameworks').findall(logfile)
            path = xbmc.translatePath(os.path.join(match[0]+'Frameworks',''))
            lib=os.path.join(path, 'librtmp.0.dylib')
            try:


                os.remove(lib)
            except:
                pass
            url = 'https://dl.dropbox.com/s/4txeogr1oekxncm/librtmp.0.dylib'
            DownloaderClass(url,lib)
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       Thats It All Done Please Come Visit Again", "Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        except: 
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       CANT UPDATE YOUR LIB FILE SORRY!!!", "Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
            
    if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
        try:    
            path = xbmc.translatePath(os.path.join('/data/data/org.xbmc.kodi/lib',''))
            lib=os.path.join(path, 'librtmp.so')
            try:
                os.remove(lib)
            except:
                pass
            url = 'https://dl.dropbox.com/s/ifkbouqs8y48lej/librtmp.so'
            DownloaderClass(url,lib)
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        except: 
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "       CANT UPDATE YOUR LIB FILE SORRY!!!", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
    print '########################### LIB LOCATION ####################'
    print lib
    
def Shrink(db):
    from sqlite3 import dbapi2 as sqlite3
    try:
        db   = xbmc.translatePath(db)
        conn = sqlite3.connect(db, timeout = 10, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread = False)
        c    = conn.cursor()

        c.execute("DELETE FROM texture WHERE id > 0")       
        c.execute("VACUUM")       

        conn.commit()
        c.close()
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "Sorry There Was A Problem Please Manually ", "Delete Textures.db")
        
    
def GetFile(filepath):
     import glob
     path = filepath
     for infile in glob.glob(os.path.join(path, 'Textures*.*')):
         File=infile
         print infile
     return File
    
     
def howtos(url,fanart):
        GA("Maintenance","How To Videos")
        link=OPEN_URL(url)
        match=re.compile('i="(.+?)" n="(.+?)" u="(.+?)" d="(.+?)"').findall(link)
        for icon, name, youtube , description in match:
                if icon=='none':
                    iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % youtube
                else:
                    iconimage=str(icon)
                print iconimage
                fanart=str(fanart)
                url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % youtube
                addLink(name,url,iconimage,description,fanart)        
                setView('movies', 'SUB') 
                
def PLAY_STREAM(name,url,iconimage,description):
    GA("How To Videos",name)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    liz.setProperty("IsPlayable","true")
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    pl.add(url, liz)
    xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
     
def uploadlog(url): 
    GA("Maintenance","Upload Log")
#    if ADDON.getSetting('email')=='':
#        dialog = xbmcgui.Dialog()
#        dialog.ok("ALLfree.TV", "A New Window Will Now Open For You To In Put", "Your Email Address For The Logfile To Be Emailed To")
#        ADDON.openSettings()
    addon.LogUploader()
    
############################################################        SKIN          ###############################################################    
    
def fastcoloreden(url,iconimage):    
        GA("Maintenance","Install BDTV Skin")
        link=OPEN_URL(url)
        match=re.compile('skinurl="(.+?)" name"(.+?)" icon="(.+?)"').findall(link)
        for url,name,iconimage in match:
            addDir(name,url,17,iconimage,'','Download '+str(name))
            
def downloadanything(url,name):     
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, name)
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
    time.sleep(4)
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))
    dialog = xbmcgui.Dialog()
    if dialog.yesno("ALLfree.TV", "Would You Like To Change Skin Now", "Window Will Change To Apperance Settings"):
        xbmc.executebuiltin("XBMC.ActivateWindow(appearancesettings)")
    
         ############################################################        BDTV INSTALLER           ###############################################################    
def BDTVInstaller(url):
    GA("Maintenance","BDTV Installer")
    print '############################################################        BDTV INSTALLER          ###############################################################'
    path = os.path.join(xbmc.translatePath('special://home'),'userdata', 'sources.xml')

    if not os.path.exists(path):
        f = open(path, mode='w')
        f.write('<sources><files><source><name>BDTV-Installer-2018</name><path pathversion="1">http://allfreetv.square7.ch/</path></source></files></sources>')
        f.close()
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "Reboot To Take Effect Then Come", "Back Here To Install Your Plugins")
        return
        
    f   = open(path, mode='r')
    str = f.read()
    f.close()
    if 'http://allfreetv.square7.ch/' in str:
        dialog = xbmcgui.Dialog()
        if dialog.yesno("ALLfree.TV", "Please Select Install From Zip Then ", "Select BDTV Installer On The Right Hand Side"):
            xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
            xbmc.executebuiltin("XBMC.ActivateWindow(AddonBrowser)")
    if not'http://allfreetv.square7.ch/' in str:
        if '</files>' in str:
            str = str.replace('</files>','<source><name>BDTV-Installer-2018</name><path pathversion="1">http://allfreetv.square7.ch/</path></source></files>')
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "Reboot To Take Effect Then Come", "Back Here To Install Your Plugins")
            f = open(path, mode='w')
            f.write(str)
            f.close()
        else:
            str = str.replace('</sources>','<files><source><name>BDTV-Installer-2018</name><path pathversion="1">http://bdtv.square7.ch/bdtv/</path></source></files></sources>')
            dialog = xbmcgui.Dialog()
            dialog.ok("ALLfree.TV", "Reboot To Take Effect Then Come", "Back Here To Install Your Plugins")
            f = open(path, mode='w')
            f.write(str)
            f.close()
			
            
############################################################        TvOnDesi Update         ###############################################################    
                
def desizone(url):
    GA("Fixes","BDTV desiZONE update")
    print '############################################################       TvOnDesi Update           ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box will Auto-Reboot!', "      OPEN TV ON DESI ZONE AFTER BOX RESTART. ENJOY!", "     [COLOR red]BIG DEC SALE! BDTV BOX for $250 LIMITED QUANTITY.[/COLOR]", "          *****  [COLOR green]780-802-9264 bdtvbox@gmail.com[/COLOR]  *****"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && /etc/init.d/S95xbmc stop & sleep 15 && cd && rm -rf /root/.xbmc/userdata/addon_data/script.common.plugin.cache/commoncache.db ; cd ;  rm -rf /root/.xbmc/userdata/Database/Addons15.db ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/plugin.video.TVonDesiZone ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/plugin.video.tvondesizone ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/plugin.video.tvondesizonex ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/plugin.video.tvondesizonexl ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.TVonDesiZone ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.tvondesizone ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.tvondesizonex ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.tvondesizonexl ; cd ; cd /root/.xbmc/ ; wget http://7auafg.dm2302.livefilestore.com/y2mgmhnoSfdG3tAFITfSH1f3ROoE9XouU0sgrRQL_NwRCCzdpPnm6pinuJS8WC014YQQD4fp9FC0L9iHfqSwr78xNZKq5DhL1zNHO4xLw-M_1kCnIcz88hiK4OFBtKjEE-r/tvondesiupdate.tar.gz -P /root/.xbmc/ ; tar -xzf tvondesiupdate.tar.gz ; rm -rf /root/.xbmc/tvondesiupdate.tar.gz ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )
    
            
         ############################################################        1Channel v2 error           ###############################################################   
def onechannelerror(url):
    GA("Fixes","1Channel v2 error FIX")
    print '############################################################        1Channel v2 error        ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box will auto REBOOT ', "Check 1Channel 10min after reboot! [COLOR blue]bdtvbox@gmail.com[/COLOR]", "If you use BDTV Box regularly, then please tell others.", "Otherwise its hard to keep existing users updated."):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && /etc/init.d/S95xbmc stop & sleep 10 && cd && rm -rf /root/.xbmc/userdata/addon_data/plugin.video.1channel ; cd ;  rm -rf /root/.xbmc/addons/repository.bstrdsmkr ; cd ;  rm -rf /root/.xbmc/addons/repository.xbmchub ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.1channel ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.1Channel ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/script.common.plugin.cache/commoncache.db ; cd ;  rm -rf /root/.xbmc/userdata/Database/onechannelcache.db ; cd ;  rm -rf /root/.xbmc/userdata/Database/Addons15.db ;  cd ; cd /root/.xbmc/addons/ ; wget https://dl.dropboxusercontent.com/u/138808030/xbmc/1channel/1channel.tar.gz -P /root/.xbmc/addons ; tar -xzf 1channel.tar.gz ; rm -rf /root/.xbmc/addons/1channel.tar.gz ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    
    
         ############################################################        X-M1 RESET           ###############################################################   
def PIVOSgui():
    GA("Fixes","PIVOS gui")
    print '############################################################        X-M1 RESET        ###############################################################'
    addDir('X-M1 settings reset for FirmWare 2016','url',113,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its X-M1. X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')
    addDir('X-M3 settings reset for FirmWare 2016','url',114,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its X-M1. X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')


         ############################################################        X-M1 RESET           ###############################################################   
def m1gui():
    GA("PIVOS gui","M1 GUI")
    print '############################################################        X-M1 RESET        ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box will auto RESTART ', "It should solve your problem! [COLOR blue]bdtvbox@gmail.com[/COLOR]", "If you use BDTV Box regularly, then please tell others.", "Otherwise its hard to keep existing users updated."):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && /etc/init.d/S95kodi stop & sleep 10 && cd && rm -rf /root/.kodi/userdata/guisettings.xml && cd ; cd /root/.kodi/ ; wget http://allfreetv.bplaced.net/maint/M1/guisettings.xml -P /root/.kodi/userdata/ && cd && rm -rf /root/.xbmc &&  cd ;  /etc/init.d/S95kodi start'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

         ############################################################        X-M1 RESET           ###############################################################   
def m3gui():
    GA("PIVOS gui","M3 GUI")
    print '############################################################        X-M1 RESET        ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box will auto RESTART ', "It should solve your problem! [COLOR blue]bdtvbox@gmail.com[/COLOR]", "If you use BDTV Box regularly, then please tell others.", "Otherwise its hard to keep existing users updated."):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && /etc/init.d/S95kodi stop & sleep 10 && cd && rm -rf /root/.kodi/userdata/guisettings.xml && cd ; cd /root/.kodi/ ; wget http://allfreetv.bplaced.net/maint/M3/guisettings.xml -P /root/.kodi/userdata/ && cd && rm -rf /root/.xbmc &&  cd ;  /etc/init.d/S95kodi start'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

         ############################################################        1Channel v2 error           ###############################################################   
def onechannelerror(url):
    GA("Fixes","1Channel v2 error FIX")
    print '############################################################        1Channel v2 error        ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box will auto REBOOT ', "Check 1Channel 10min after reboot! [COLOR blue]bdtvbox@gmail.com[/COLOR]", "If you use BDTV Box regularly, then please tell others.", "Otherwise its hard to keep existing users updated."):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && /etc/init.d/S95xbmc stop & sleep 10 && cd && rm -rf /root/.xbmc/userdata/addon_data/plugin.video.1channel ; cd ;  rm -rf /root/.xbmc/addons/repository.bstrdsmkr ; cd ;  rm -rf /root/.xbmc/addons/repository.xbmchub ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.1channel ; cd ;  rm -rf /root/.xbmc/addons/plugin.video.1Channel ; cd ;  rm -rf /root/.xbmc/userdata/addon_data/script.common.plugin.cache/commoncache.db ; cd ;  rm -rf /root/.xbmc/userdata/Database/onechannelcache.db ; cd ;  rm -rf /root/.xbmc/userdata/Database/Addons15.db ;  cd ; cd /root/.xbmc/addons/ ; wget https://dl.dropboxusercontent.com/u/138808030/xbmc/1channel/1channel.tar.gz -P /root/.xbmc/addons ; tar -xzf 1channel.tar.gz ; rm -rf /root/.xbmc/addons/1channel.tar.gz ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    
    
         ############################################################        INSTALL BDTV REPO           ###############################################################   
def bdtvboxrepo(url):
    GA("Maintenance","BDTV Repo")
    print '############################################################        INSTALL BDTV REPO        ###############################################################'
    url = 'https://dl.dropbox.com/s/uazala8pqownm3b/repo.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'repo.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))


         ############################################################        INSTALL ADULT REPOS & ADDONS           ###############################################################   
def installadult(url):
    GA("Maintenance","Install Adult")
    print '############################################################        INSTALL ADULT REPOS & ADDONS        ###############################################################'
    url = 'https://dl.dropbox.com/s/4lhn4e8bwncfqev/adult.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if os.path.exists(path)==True: 

        lib=os.path.join(path, 'adult.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
        time.sleep(5)
        extract.all(lib,addonfolder)

    else:
        pass
    path = os.path.join(xbmc.translatePath('special://home/addons'),'plugin.video.bdtv-desilive', 'default.py')

    f   = open(path, mode='r')
    str = f.read()
    f.close()
    if not'#if (\'ADULT\' in cname)' in str:
        str = str.replace('if (\'ADULT\' in cname)','#if (\'ADULT\' in cname)')
        f = open(path, mode='w')
        f.write(str)
        f.close()
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('This will enable Adult Add-Ons and Live CHs','Live Adult CHs like PLAYBOY, HUSTLER etc. will be playing from BDTV World Live Servers', "Click OK to Restart"):
       xbmc.executebuiltin("XBMC.Quit()")	
	


		############################################################        REMOVE ADULT          ###############################################################  
  
def removeadult(url):
    GA("Fixes","removeADULT")
    print '############################################################       REMOVE ADULT          ###############################################################'
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.beeg.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.empflix')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.fantasticc')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.lubetube')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.pornhub')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.tube8')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.videodevil')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.you.jizz')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.adultdvdempire.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.aebn.gay.net')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.aebn.net')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.cduniverse.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.data18.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.data18.content.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.excaliburfilms.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://profile/addon_data', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.hotmovies.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.beeg.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.empflix')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.fantasticc')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.lubetube')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.pornhub')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.tube8')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.videodevil')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.you.jizz')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.adultdvdempire.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.aebn.gay.net')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.aebn.net')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.cduniverse.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.data18.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.data18.content.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.excaliburfilms.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.movie.hotmovies.com')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'repository.bdtvadult')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'metadata.common.themoviedb.org')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'repository.MisterX')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'repository.xbmcadult')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'repository.xbmc-adult')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.uwc')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    onechanneldatapath = xbmc.translatePath(os.path.join('special://home/addons', ''))
    onechanneldata=os.path.join(onechanneldatapath, 'plugin.video.eroticshark')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(onechanneldata):
                
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(onechanneldata)
                        
    else:
        pass
    path = os.path.join(xbmc.translatePath('special://home/addons'),'plugin.video.bdtv-desilive', 'default.py')

    f   = open(path, mode='r')
    str = f.read()
    f.close()
    if '#if (\'ADULT\' in cname)' in str:
        str = str.replace('#if (\'ADULT\' in cname)','if (\'ADULT\' in cname)')
        f = open(path, mode='w')
        f.write(str)
        f.close()
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('Adult content will be removed after restart.','Content from internet can never be 100% Adult free.',  "Click OK to RESTART"):
       xbmc.executebuiltin("XBMC.Quit()")	
	

    ############################################################       REMOVE CUSTOM MODULE        ###############################################################'
def delspcustom(url):  
    GA("Addons","sp-delete")
    print '############################################################       REMOVE CUSTOM MODULE         ###############################################################'
    modulepath = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.SportsDevil/custom',''))

    try:    
        for root, dirs, files in os.walk(modulepath):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("ALLfree.TV", "       Thats It All Done Please Come Visit Again", "          Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "Modules Wont Delete", "Sort It!!    Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
        
        

def sportscustom(name,url,iconimage):
    	print '############################################################        SportsDevil Custom Modules        ###############################################################'
    	GA("Addons","SP Custom")
        link=OPEN_URL(url)
        match=re.compile('liveurl="(.+?)" name"(.+?)" icon="(.+?)"').findall(link)
        for url,name,iconimage in match:
            addDir(name,url,904,iconimage,'','Download '+str(name))

def copy_sp_list(name,url,iconimage):     
    GA("SP Custom","name")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'custom.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.video.SportsDevil',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

         ############################################################        SportsDevil Main Modules           ###############################################################   
def sportsmain(url):
    GA("Addons","Sports Devil Main")
    print '############################################################        SportsDevil Main Modules        ###############################################################'
    url = baseone+'sportsdevil/resources.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'resources.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.SportsDevil',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

         ############################################################        Category List           ###############################################################   
def categorylist(url):
    GA("Addons","Category List")
    print '############################################################      Category List           ###############################################################'
    url = baseone+'userdata/categoriesfull.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'categoriesfull.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

         ############################################################        Geo Unlock           ###############################################################   
def geounlock(url):
    GA("Addons","Geo Unlock")
    print '############################################################      Geo Unlock           ###############################################################'
    url = baseone+'userdata/hulu%20and%20iPlayer/userdata.zip'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'userdata.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))
    dialog = xbmcgui.Dialog()
    if dialog.yesno("One of BDTV Box EXCLUSIVE", "                  NEEDS REBOOT TO TAKE EFFECT", "WANT TO REBOOT NOW?               www.fb.com/AFTbox"):
       xbmc.executebuiltin("XBMC.Quit()")	



############################################################        Restore Country          ###############################################################    
def deletegeo(url):
    GA("Addons","Delete Geo")
    print '############################################################       Restore Country          ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    delgeo=os.path.join(path, 'myResolv.conf')
    os.remove(delgeo)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("NEEDS REBOOT TO TAKE EFFECT", "WANT TO REBOOT NOW?               www.fb.com/AFTbox"):
       xbmc.executebuiltin("XBMC.Quit()")	


    ############################################################        Recovery        ###############################################################
def doRecovery(url = None):
    GA("Check Linux","Enter Recovery")
    print '############################################################        Recovery        ###############################################################'
    dialog = xbmcgui.Dialog()
    if (url == None) or ('BDTV Box, CLICK YES TO CONFIRM', "IF SCREEN GOES BLANK FOR MORE THEN 2 MINUTES! JUST", "PLUG-OUT, PRESS AND HOLD UPGRADE BUTTON, PLUG-IN", "AND RELEASE BUTTON WHEN RECOVERY SCREEN DISPLAY"):
       os.system('reboot recovery')

    ############################################################        Screen FIX        ###############################################################
def screenfix(url = None):
    GA("None","ScreenFIX")
    print '############################################################        Symlink & RESTORE ADDONS       ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box', "All short-cuts, time settings etc. will erase", "screen will fix after auto-reboot"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && sleep 10 ; rm -rf /root/.xbmc/userdata/guisettings.xml ; sleep 10 ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

    ############################################################        Reboot        ###############################################################
def reboot(url = None):
    print '############################################################       Reboot        ###############################################################'
    dialog = xbmcgui.Dialog()
    if (url == None) or ('BDTV Box', "Force Reboot"):
       os.system('reboot')
       
    ############################################################        Remove Mikey        ###############################################################
def removemikey(url):
    print '############################################################        Remove Mikey       ###############################################################'
    for root, dirs, files in os.walk(url):
        for f in files:
            os.unlink(os.path.join(root, f))
        for d in dirs:
            shutil.rmtree(os.path.join(root, d))
    os.rmdir(url)
    
    
        ############################################################       Restore Userdata       ###############################################################'
def restore(url):
        GA("Maintenance","Restore Userdata")
        print '############################################################       Restore Userdata       ###############################################################'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        zippath=os.path.join(path, boxbackupzip)
        DownloaderClass(url,zippath)
        userdata = xbmc.translatePath(os.path.join('special://profile/addon_data/',''))
        time.sleep(3)
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(zippath,userdata))
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", "Thats It All Done", " Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
        os.remove(zippath)
        if xbmc.getCondVisibility('system.platform.ATV2'):
            os.chmod(userdata, stat.S_IRWXO)        
        
         ############################################################        CAPTCHA FIX           ###############################################################   
def captcha(url):
    GA("Fixes","Add Captcha")
    print '############################################################        CAPTCHA FIX       ###############################################################'
    url = 'https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/fix/vidxden.py'
    path = xbmc.translatePath(os.path.join('special://home/addons/script.module.urlresolver/lib/urlresolver/','plugins'))
    lib=os.path.join(path, 'vidxden.py')
    DownloaderClass(url,lib)
    url = 'https://dl.dropboxusercontent.com/u/129714017/hubmaintenance/fix/putlocker.py'
    path = xbmc.translatePath(os.path.join('special://home/addons/script.module.urlresolver/lib/urlresolver/','plugins'))
    lib=os.path.join(path, 'putlocker.py')
    DownloaderClass(url,lib)
    
    
    ############################################################       REMOVE ADDON             ###############################################################'
def findaddon(url,name):  
    GA("Maintenance",name)
    print '############################################################       REMOVE ADDON             ###############################################################'
    pluginpath = xbmc.translatePath(os.path.join('special://home/addons',''))
    import glob
    for file in glob.glob(os.path.join(pluginpath, url+'*')):
        name=str(file).replace(pluginpath,'').replace('plugin.','').replace('video.','').replace('hub','BDTV-').replace('skin.','').replace('repository.','')
        iconimage=(os.path.join(file,'icon.png'))
        fanart=(os.path.join(file,'fanart.jpg'))
        addDir(name,file,26,iconimage,fanart,'')
        setView('movies', 'SUB') 
        
    ############################################################       REMOVE ADDON DATA        ###############################################################'
def findaddondata(url,name):  
    GA("Maintenance",name)
    print '############################################################       REMOVE ADDON DATA         ###############################################################'
    pluginpath = xbmc.translatePath(os.path.join('special://profile/addon_data/',''))
    import glob
    for file in glob.glob(os.path.join(pluginpath, url+'*')):
        name=str(file).replace(pluginpath,'').replace('plugin.','').replace('video.','').replace('hub','BDTV-').replace('skin.','').replace('repository.','')
        iconimage=(os.path.join(file,'icon.png'))
        fanart=(os.path.join(file,'fanart.jpg'))
        addDir(name,file,26,iconimage,fanart,'')
        setView('movies', 'SUB') 
        
         ############################################################        SUBTITLE FIX           ###############################################################   
def subtitle(url):
    GA("Fixes","1Galaxy Fix")
    print '############################################################        SUBTITLE FIX       ###############################################################'
#    for root, dirs, files in os.walk(url):
#        for f in files:
#            os.unlink(os.path.join(root, f))
#        for d in dirs:
#            shutil.rmtree(os.path.join(root, d))
#    os.rmdir(url)
    path = xbmc.translatePath(os.path.join('special://profile/Database', ''))
    onechanneldata=os.path.join(path, 'saltscache.db')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(url):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.remove(onechanneldata)
                        
    else:
        pass
    path = xbmc.translatePath(os.path.join('special://profile/Database', ''))
    onechanneldata=os.path.join(path, 'saltscache.db-shm')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(url):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.remove(onechanneldata)
                        
    else:
        pass
    path = xbmc.translatePath(os.path.join('special://profile/Database', ''))
    onechanneldata=os.path.join(path, 'saltscache.db-wal')
    if os.path.exists(onechanneldata)==True: 
        for root, dirs, files in os.walk(url):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.remove(onechanneldata)
                        
    else:
        pass
    dialog = xbmcgui.Dialog()
    if dialog.yesno('Click YES to Quit now and open BDTV again', "Quit to take effect, After you click YES and wait", "to for Android to run BDTV again"):
       xbmc.executebuiltin("XBMC.Quit()")	

    
    
         ############################################################       SLOW GUI          ###############################################################    
def gui(url):
    GA("Fixes","Slow Gui")
    print '############################################################        SLOW GUI         ###############################################################'
    path = os.path.join(xbmc.translatePath('special://home'),'userdata', 'advancedsettings.xml')
    try:
        f   = open(path, mode='r')
        str = f.read()
        f.close()
        if '<algorithmdirtyregions>3</algorithmdirtyregions>' in str:
                str = str.replace('<algorithmdirtyregions>3</algorithmdirtyregions>','<algorithmdirtyregions>0</algorithmdirtyregions>')
                dialog = xbmcgui.Dialog()
                dialog.ok("ALLfree.TV", 'You Had Dirty Regions Set To "3"', "All Fixed And Disabled")
                f = open(path, mode='w')
                f.write(str)
                f.close()
        else:
                dialog = xbmcgui.Dialog()
                dialog.ok("ALLfree.TV", 'You Have Not Got Dirty Regions "3"', "So Sorry You Just Have A Slow Box")
                f = open(path, mode='w')
                f.write(str)
                f.close()
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok("ALLfree.TV", 'You Have Not Got Any Advanced Settings Anyway', "So Sorry You Just Have A Slow Box")
        
            
def select_build(): 
    dialog=xbmcgui.Dialog()
    version_select=['Frodo','Eden']
    select=['Frodo','Eden']
    return version_select[xbmcgui.Dialog().select('Please Choose Your Build', select)]
   
         ############################################################       DM ADULT ON           ###############################################################   
def DMadulton(name):
    GA("Addons","ADULT ON")
    print '############################################################       DM ADULT ON       ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box', "THIS STEP WILL ENABLE ADULT CONTENT", "IN YAMGO AT SPORTSDEVIL AND DAILYMOTION ADDON"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && cat /dev/null >> /root/.xbmc/userdata/addon_data/plugin.video.dailymotion_com/family_filter_off ; cd ; cd /root/.xbmc/userdata/addon_data/plugin.video.SportsDevil/custom/ ; wget https://dl.dropboxusercontent.com/u/138808030/xbmc/adulton/adulton/yamgo.com.cfg -O /root/.xbmc/userdata/addon_data/plugin.video.SportsDevil/custom/yamgo.com.cfg'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

         ############################################################       DM ADULT OFF           ###############################################################   
def DMadultoff(name):
    GA("Addons","ADULT OFF")
    print '############################################################       DM ADULT OFF       ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box', "THIS STEP WILL REMOVE ADULT CONTENT", "IN YAMGO AT SPORTSDEVIL AND DAILYMOTION ADDON"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && rm -rf /root/.xbmc/userdata/addon_data/plugin.video.dailymotion_com/family_filter_off ; cd ; cd /root/.xbmc/userdata/addon_data/plugin.video.SportsDevil/custom/ ; wget https://dl.dropboxusercontent.com/u/138808030/xbmc/adulton/adultoff/yamgo.com.cfg -O /root/.xbmc/userdata/addon_data/plugin.video.SportsDevil/custom/yamgo.com.cfg'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

    ############################################################        DELETE THUMBNAILS          ####################################################
def deleteThumbnails():
    GA("Fixes","Thumbnail Delete")
    print '############################################################        DELETE THUMBNAILS       ###############################################################'
    if os.path.exists(thumbnailPath)==True:  
        for root, dirs, files in os.walk(thumbnailPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:                
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                    except:
                        pass                
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    os.unlink(text13)
        
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Restart Needed', "Click yes if you want to do it now!","if BDTV don't exit or reboot do it manualy"):
       xbmc.executebuiltin("XBMC.Quit()")	
        

	   ############################################################        1Channel Domain       ###############################################################
    ############################################################        RENEW THUMBNAILS          ####################################################
def removeICONtexture(name,url,iconimage):
    GA("Fixes","Icon fix")
    print '############################################################        RENEW THUMBNAILS       ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box. CLICK YES', "BOX WILL REBOOT TO TAKE EFFECT!"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd ; /etc/init.d/S95xbmc stop & sleep 10 && CD ; cd /root/.xbmc/userdata/Database/ && rm -f Textures13.db ; cd ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

	   ############################################################        1Channel Domain       ###############################################################
def onechanneldown(url):
    GA("Fixes","1Channel URL error")
    print '############################################################        1Channel Domain    ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.1channel','resources'))
    settings=os.path.join(path, 'settings.xml')
    f   = open(settings, mode='r')
    str = f.read()
    f.close()
    replacewith=str.replace('<setting id="domain" type="labelenum" label="Domain" values="http://www.1channel.ch|http://www.letmewatchthis.ch" default="http://www.letmewatchthis.ch"/>','<setting id="domain" type="labelenum" label="Domain" values="http://www.1channel.ch|http://www.letmewatchthis.ch|http://www.primewire.ag" default="http://www.primewire.ag"/>')
    f = open(settings, mode='w')
    f.write(replacewith)
    f.close()
    channel=xbmcaddon.Addon(id='plugin.video.1channel')
    channel.setSetting('domain','http://www.primewire.ag')
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "All Done Thanks", "Contact for reference program. +1 780 802 9264")


    ############################################################       Fire Stv KB-xml       ###############################################################
def andKB(name):
    GA("Remotes","And-KB")
    ############################################################       Fire Stv KB-xml       ###############################################################
    path = xbmc.translatePath(os.path.join('special://home/userdata/keymaps',''))
    lib=os.path.join(path, 'keyboard.xml')
    url = 'https://dl.dropbox.com/s/3nr2tom5436fyna/keyboard.xml'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    dialog.ok("Reopen BDTV", "Exit and reopen BDTV to take effect", "  www.fb.com/AFTbox")

    print '############################################################       Linux KB-xml       ###############################################################'
def addkeyboardxml(name):
    GA("Remotes","Lin-KB")
    print '############################################################       Linux KB-xml       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/userdata/keymaps',''))
    lib=os.path.join(path, 'keyboard.xml')
    url = aftsq7+'remotes/lin-keyboard.xml'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("REBOOT for effect", "Click YES to Reboot now or NO to use remote reboot later", "Eh! I am still supporting my 5yr old devices <:)  www.fb.com/AFTbox"):
       os.system('reboot')

    print '############################################################       Remote RM-V301       ###############################################################'
def remoteRM301(name):
    GA("Remotes","RM-V301")
    print '############################################################       Remote RM-V301       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/RM-V301/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AND REBOOT", "PRESS:   S >> DVD >> [COLOR orange]016[/COLOR] >> ENT >> DVD on REMOTE.", "WANT TO REBOOT NOW?               www.fb.com/AFTbox"):
       os.system('reboot')

    print '############################################################       Remote X-Ms       ###############################################################'
def remoteXM(name):
    GA("Remotes","RM-V301")
    print '############################################################       Remote X-Ms       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/X-M-original/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AND REBOOT", "GO TO MYHARMONY.COM, SET PIVOS>>XIOS ON NEW ", "LOGITECH HARMONY REMOTE. DONE!    bdtvbox@gmail.com", "                       WANT TO REBOOT NOW?"):
       os.system('reboot')
	    
	############################################################       Remote SRP1003       ###############################################################'
def srp1003(name):
    GA("Remotes","PHILIPS-SRP1003")
    print '############################################################       Remote SRP1003       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/PHILIPS/SRP1003/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AND REBOOT", "PRESS [COLOR orange]SETUP[/COLOR] AND WAIT FOR [COLOR red]STEADY RED LED[/COLOR], NOW CLICK","[COLOR orange]DVD[/COLOR] >> [COLOR orange]0843[/COLOR] >> [COLOR orange]MUTE[/COLOR]. ALL DONE!    bdtvbox@gmail.com", "                           WANT TO REBOOT NOW?"):
       os.system('reboot')

	############################################################       Remote SRP2003       ###############################################################'
def srp2003(name):
    GA("Remotes","PHILIPS-SRP2003")
    print '############################################################       Remote SRP2003       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/PHILIPS/SRP2006/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AFTER REBOOT", "PRESS n hold [COLOR orange]DVD[/COLOR] TILL [COLOR red]LED[/COLOR] BLINKS, ENTER CODE [COLOR orange]2085[/COLOR]. NOW", "PRESS n HOLD [COLOR orange]POWER[/COLOR] KEY UNTILL SEE SHUT DOWN MENU.", "CLICK [COLOR orange]DVD[/COLOR] TWICE TO SAVE SETTING. bdtvbox@gmail.com"):
       os.system('reboot')

	############################################################       RCA  RCRN04GR       ###############################################################'
def RCRN04GR(name):
    GA("Remotes","RCRN04GR")
    print '############################################################       Remote RCRN04GR       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/RCA/RCRN04GR/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AND REBOOT", "ENTER [COLOR orange]30503[/COLOR] WHILE HOLDING [COLOR orange]DVD-VCR[/COLOR] ON REMOTE. DONE!", "                           bdtvbox@gmail.com", "                       WANT TO REBOOT NOW?"):
       os.system('reboot')

         ############################################################       REMOVE SD DATA           ###############################################################   
def jp505(name):
    GA("Remotes","RCRN04GR")
    print '############################################################       Remote RCRN04GR       ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home',''))
    lib=os.path.join(path, 'remote.conf')
    url = aftsq7+'remotes/ZENITH/jp505/remote.conf'
    DownloaderClass(url,lib)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("DO FOLLOWING AFTER REBOOT", "PRESS n hold [COLOR orange]AUX[/COLOR] TILL STEADY[COLOR red]LED[/COLOR] COMES ON", "ENTER CODE [COLOR orange]0814[/COLOR].", "REBOOT AND ENJOY! bdtvbox@gmail.com"):
       os.system('reboot')

         ############################################################       REMOVE SD DATA           ###############################################################   
def removeSDdata(name,url,iconimage):
    GA("Firmware","SD data remove")
    print '############################################################       REMOVE SD DATA       ###############################################################'
    dialog = xbmcgui.Dialog()
    dialog.ok("PREPARING FOR FIRMWARE UPDATE", "AFTER AUTO REBOOT (1-15minutes). COME BACK", "TO BDTV MAINTENANCE FOR STEP-3 AND 4")
    from subprocess import Popen, PIPE, STDOUT
    cmd = 'cd ; /etc/init.d/S95xbmc stop & sleep 10 && cd && mv -f /media/sdcard/xbmc-data/userdata/xios/root/.xbmc /media/sdcard/xbmc-data/userdata/xios/root/xbmc ; cd ; mv -f /media/sdcard/xbmc-data/userdata/xios/root/.ash_history /media/sdcard/xbmc-data/userdata/xios/root/history ; cd ; mv -f /media/sdcard/xbmc-data /media/sdcard/deleteme ; sleep 10 ; reboot'
    Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    
	    
def downloadapps(name,url,iconimage):
        print '############################################################     SETUP RESTORE       ###############################################################'
        GA("None","ADDONS RESTORE")
        link=OPEN_URL(url)
        match=re.compile('Download="(.+?)" Data Name: (.+?)" icon="(.+?)"').findall(link)
        for url,name,iconimage in match:
            addDir(name,url,508,iconimage,'','Download '+str(name))
                
def copy_addon_setup(name,url,iconimage):
    GA("Firmware","data zip file")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'datarestore.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home',''))
    time.sleep(10)
    extract.all(lib,addonfolder)
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Click Yes to RESTART", "After restart come back and finish last step", "REBOOT NOW. bdtvbox@gmail.com"):
       os.system('reboot')
       
def livelist(name,url,iconimage):
        print '############################################################     LIVE LIST       ###############################################################'
        GA("None","LIVE LIST")
        link=OPEN_URL(url)
        match=re.compile('liveurl="(.+?)" name"(.+?)" icon="(.+?)"').findall(link)
        for url,name,iconimage in match:
            addDir(name,url,903,iconimage,'','Download '+str(name))
            
def customPlugin(name,url,iconimage):
        print '############################################################     Custom Plugin       ###############################################################'
        GA("None","Custom Plugin")
        link=OPEN_URL(url)
        match=re.compile('liveurl="(.+?)" name"(.+?)" icon="(.+?)"').findall(link)
        for url,name,mode in match:
            addDir(name,url,mode,'','','Download '+str(name))
            
def copy_live_list(name,url,iconimage):     
    GA("LIVE LIST","name")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data','plugin.video.live.streamspro'))
    lib=os.path.join(path, 'source_file')
    DownloaderClass(url,lib)
                
    ############################################################        Symlink & RESTORE ADDONS       ###############################################################
def restoreapps(name,url,iconimage):
    GA("None","Symlink")
    print '############################################################        Symlink & RESTORE ADDONS       ###############################################################'
    dialog = xbmcgui.Dialog()
    if dialog.yesno('BDTV Box', "AFTER  AUTO-REBOOT  BOX  WILL  TAKE  COUPLE", "OF  HOURS  TO  POPULATE  ADDONS! REBOOT THEN"):
       from subprocess import Popen, PIPE, STDOUT
       cmd = 'cd && rm -rf /media/sdcard/deleteme & sleep 10 ; cd ; mkdir -p /media/sdcard/Thumbnails ; cd ; rm -rf /root/.kodi/userdata/Thumbnails ; cd ; cd /root/.kodi/ ; tar -xzf datarestore.tar.gz & sleep 30 ; cd ; rm -rf /root/.kodi/datarestore.tar.gz ; cd ; rm -f /root/.kodi/userdata/Database/Textures13.db ; cd ; rm -rf /media/sdcard/update.img ; sleep 10 ; reboot'
       Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )    

    ############################################################        Symlink AT INSTALLATION       ###############################################################
def symlinksetup(name,url,iconimage):
    GA("PIVOS FM","Step-2")
    print '############################################################        Symlink AT INSTALLATION       ###############################################################'
    addDir('MODEL: X-M1 Configuration','url',907,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its X-M1. X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')
    addDir('MODEL: X-M3 Configuration','url',908,base+'images/x-m1-m3.jpg',base+'images/x-m1-m3.jpg','Check serial number on box back. If it have "M3" in, then its X-M3 model. Otherwise its X-M1. X-M1 --> S/N: 0002 G X XX XX XXXX.    X-M3 --> S/N: 0002 G M3 X XX XX XXXX')

    ############################################################        Symlink AT INSTALLATION       ###############################################################
def m1setup():
    GA("PIVOS M1","restore")
    print '############################################################        Symlink AT INSTALLATION       ###############################################################'
    from subprocess import Popen, PIPE, STDOUT
    cmd = 'cd && rm -rf /media/sdcard/deleteme & sleep 10 ; cd ; mkdir -p /media/sdcard/Thumbnails ; cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.live.streams ; cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.dailymotion_com ; cd ; rm -rf /root/.kodi/userdata/Thumbnails ; cd ; ln -s /media/sdcard/Thumbnails /root/.kodi/userdata/Thumbnails ; cd ; rm -f /root/.kodi/userdata/Database/Textures13.db ; cd && cd /root/.kodi/ ; wget http://allfreetv.bplaced.net/maint/M1/drivelinks.tar.gz -P /root/.kodi/ && tar -xzf drivelinks.tar.gz && rm -rf /root/.kodi/drivelinks.tar.gz ; cd ; rm -rf /media/sdcard/update.img && cd && rm -rf /root/.xbmc && sleep 5 ; reboot'
    Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )
      
    ############################################################        Symlink AT INSTALLATION       ###############################################################
def m3setup():
    GA("PIVOS M3","restore")
    print '############################################################        Symlink AT INSTALLATION       ###############################################################'
    from subprocess import Popen, PIPE, STDOUT
    cmd = 'cd && rm -rf /media/sdcard/deleteme & sleep 10 ; cd ; mkdir -p /media/sdcard/Thumbnails ; cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.live.streams ; cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.dailymotion_com ; cd ; rm -rf /root/.kodi/userdata/Thumbnails ; cd ; ln -s /media/sdcard/Thumbnails /root/.kodi/userdata/Thumbnails ; cd ; rm -f /root/.kodi/userdata/Database/Textures13.db ; cd && cd /root/.kodi/ ; wget http://allfreetv.bplaced.net/maint/M3/drivelinks.tar.gz -P /root/.kodi/ && tar -xzf drivelinks.tar.gz && rm -rf /root/.kodi/drivelinks.tar.gz ; cd ; rm -rf /media/sdcard/update.img && cd && rm -rf /root/.xbmc && sleep 5 ; reboot'
    Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )
      
def intialsetup(name,url,iconimage):
    print '############################################################        Symlink AT INSTALLATION       ###############################################################'
    from subprocess import Popen, PIPE, STDOUT
    cmd = 'cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.live.streamspro ; cd ; mkdir -p /root/.kodi/userdata/addon_data/plugin.video.dailymotion_com ; rm -rf /root/.kodi/drivelinks.tar.gz'
    Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT )
      
def image_select():
	dialog = xbmcgui.Dialog()
	select=['X-M1','X-M3']
	image_select=['BDTV BOX X-M1 (ORIGINAL) SOLD TILL FEB-24-2013','BDTV BOX X-M3','GO BACK']
	return select[xbmcgui.Dialog().select('Select your BDTV Box model ?', image_select)]

def linux_image(url,name,iconimage):
        yourversion='[COLOR yellow]YOUR CURRENT FIRMWARE RELEASE DATE: %s[/COLOR]'%(myversion())
        addDir(yourversion,'url',34,iconimage,'',name)
        print '############################################################     LINUX IMAGE       ###############################################################'
        GA("None","Check Linux")
        link=OPEN_URL(url)
        r='Firmware Release %s Date:(.+?)" download="(.+?)"'%(image_select())
        uniques=[]
        match=re.compile(r).findall(link)
        for name,url in match:
            if name not in uniques:
                uniques.append(name)
                addDir('AVAILABLE FIRMWARE UPDATE RELEASE DATE: '+name,url,34,iconimage,'','To Install This Image Please Go Ahead And Click on The One you Desire')       
                setView('movies', 'default') 
                
def install_linux_image(name,url,iconimage):
    GA("Check Linux","Installing")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('media/sdcard',''))
    lib=os.path.join(path, 'update.img')
    DownloaderClass(url,lib)
    if dialog.yesno("[COLOR red]BOX WILL REBOOT IN FIRMWARE UPDATE MENU[/COLOR]", 'IF X-M3, CHOOSE INSTALL FROM SD CARD>>update.img','', "[COLOR red]REBOOT WHEN FINISH. X-M1 WILL DO ALL AUTOMATIC[/COLOR]"):
        doRecovery(url)       

	
def linux_imageBK(url,name,iconimage):
        yourversion='[COLOR yellow]YOUR CURRENT FIRMWARE RELEASE DATE: %s[/COLOR]'%(myversion())
        addDir(yourversion,'url',38,iconimage,'',name)
        print '############################################################     LINUX IMAGE       ###############################################################'
        GA("None","Check Linux")
        link=OPEN_URL(url)
        r='Firmware Release %s Date:(.+?)" download="(.+?)"'%(image_select())
        uniques=[]
        match=re.compile(r).findall(link)
        for name,url in match:
            if name not in uniques:
                uniques.append(name)
                addDir('Download backup FIRMWARE UPDATE: '+name,url,38,iconimage,'','This will download update-14-bk.img')       
                setView('movies', 'default') 
                
def install_linux_imageBK(name,url,iconimage):
    GA("Check Linux","Installing-BK")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('media/sdcard',''))
    lib=os.path.join(path, 'update-14-bk.img')
    DownloaderClass(url,lib)
    dialog.ok("[COLOR red]PROCCED to STEP-1[/COLOR]", 'You just downloaded backup Firmware, in case main update won\'t work','', "[COLOR red]Back Firmware will be update-14-bk.img[/COLOR]")

	
def myversion():
   if xbmc.getCondVisibility('system.platform.osx'):
       if xbmc.getCondVisibility('system.platform.atv2'):
           log_path = '/var/mobile/Library/Preferences'

       else:
           log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
   elif xbmc.getCondVisibility('system.platform.ios'):
       log_path = '/var/mobile/Library/Preferences'
   elif xbmc.getCondVisibility('system.platform.windows'):
       log_path = xbmc.translatePath('special://home')
       log = os.path.join(log_path, 'xbmc.log')
       logfile = open(log, 'r').read()
   elif xbmc.getCondVisibility('system.platform.linux'):
       log_path = xbmc.translatePath('special://home/temp')
   elif xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
       log_path = xbmc.translatePath('special://home/temp')
   else:
       log_path = xbmc.translatePath('special://logpath')
   log = os.path.join(log_path, 'xbmc.log')
   logfile = open(log, 'r').read()
   match=re.compile('Built on (.+?)\n').findall(logfile)
   result=match[0]
   regex=re.compile('(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)')
   match=regex.search(result)
   date='%s%s%s%s%s%s%s%s%s%s%s'%(match.group(1),match.group(2),match.group(3),match.group(4),match.group(5),match.group(6),match.group(7),match.group(8),match.group(9),match.group(10),match.group(11))
   return date


def apk_load(name,url,iconimage):
    print '############################################################     APK DownLoad       ###############################################################'
    GA("","APK LIST")
    link=OPEN_URL(url)
    r='apk %s name:(.+?)" icon="(.+?)" download="(.+?)"'%(android_select())
    uniques=[]
    match=re.compile(r).findall(link)
    for name,iconimage,url in match:
        if name not in uniques:
            uniques.append(name)
            addDir(name,url,1038,iconimage,'','Download '+str(name)+' file. Then install from file manager going to open next' )       
            setView('movies', 'default') 
            
        
def apk_install(name,url,iconimage):     
    GA("APK LIST","Installing")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('/storage/emulated/0/'))
    lib=os.path.join(path, name)
    DownloaderClass(url,lib)
    dialog.ok("[COLOR green]NEXT STEP[/COLOR]", "File Manager will open, choose the desired apk file and Install.", "When Finish, Click Done")
    xbmc.executebuiltin('XBMC.StartAndroidActivity("com.estrongs.android.pop")')             

def factoryDATA(name,url,iconimage):     
    GA("APK LIST","Installing")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('/storage/emulated/0/'))
    lib=os.path.join(path, name)
    DownloaderClass(url,lib)
    dialog.ok("[COLOR green]NEXT STEP[/COLOR]", "Restore Factory Data or as instructed")

def android_select():
	dialog = xbmcgui.Dialog()
	select=['ARM','x86']
	android_select=['Amazon Fire TV','Google NEXUS PLAYER (most updated and most apps are compatible with FireTV other then Firmware & few apps)','GO BACK']
	return select[xbmcgui.Dialog().select('Select your BDTV Device model ?', android_select)]

def BDTVapk_update(url,name,iconimage):
        yourversion='[COLOR yellow]YOUR CURRENT BDTV RELEASE DATE: %s[/COLOR]'%(ANDROIDversion())
        addDir(yourversion,'url',1036,iconimage,'',name)
        print '############################################################     APK Update       ###############################################################'
        GA("None","Check Android")
        link=OPEN_URL(url)
        r='Firmware Release %s Date:(.+?)" download="(.+?)"'%(android_select())
        uniques=[]
        match=re.compile(r).findall(link)
        for name,url in match:
            if name not in uniques:
                uniques.append(name)
                addDir('AVAILABLE BDTV UPDATE DATE: '+name,url,1036,iconimage,'','To Install This Update Please Go Ahead And Click on The One you Desire')       
                setView('movies', 'default') 
                
def BDTVapk_install(name,url,iconimage):
    GA("Check BDTV-APK","Installing")
    dialog = xbmcgui.Dialog()
    path = xbmc.translatePath(os.path.join('/storage/emulated/0/'))
    lib=os.path.join(path, 'BDTV-Update.apk')
    DownloaderClass(url,lib)
    dialog.ok("[COLOR green]NEXT STEP[/COLOR]", "File Manager will open, choose [COLOR blue]BDTV-Update.apk[/COLOR] and Install.", "Check instructions if you need to un-install old BDTV app")
    xbmc.executebuiltin('XBMC.StartAndroidActivity("com.estrongs.android.pop")')             


	
def ANDROIDversion():
   if xbmc.getCondVisibility('system.platform.osx'):
       if xbmc.getCondVisibility('system.platform.atv2'):
           log_path = '/var/mobile/Library/Preferences'

       else:
           log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
   elif xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'):
       log_path = xbmc.translatePath('special://home/temp')
   else:
       log_path = xbmc.translatePath('special://logpath')
   log = os.path.join(log_path, 'kodi.log')
   logfile = open(log, 'r').read()
   match=re.compile('Kodi compiled (.+?)by').findall(logfile)
   result=match[0]
   regex=re.compile('(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)(.+?)')
   match=regex.search(result)
   date='%s%s%s%s%s%s%s%s%s%s%s'%(match.group(1),match.group(2),match.group(3),match.group(4),match.group(5),match.group(6),match.group(7),match.group(8),match.group(9),match.group(10),match.group(11))
   return date

def removeanything(url):   
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Remove", '', "Do you want to Remove"):
        for root, dirs, files in os.walk(url):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(url)
        xbmc.executebuiltin('Container.Refresh')   
    
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "Thank You It is Now Removed", "Brought To You By www.ALLfree.TV or fb.com/AFTbox")
    
############################################################        HULU FIX          ###############################################################    
def hulufix(url):  
    GA("None","Hulu")
    print '############################################################        HULU FIX        ###############################################################'
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, 'script.module.cryptopy.zip')
    DownloaderClass(url,lib)
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
    xbmc.executebuiltin("XBMC.Extract(%s,%s,%s)"%(lib,addonfolder))
    dialog = xbmcgui.Dialog()
    dialog.ok("ALLfree.TV", "       Thats It All Done RESTART IF NEEDED", "          Brought To You By BDTBOX.BLOGSPOT.CA and ALLfree.TV")
   
############################################################        ADD 7 ICONS          ###############################################################    
    
def add7icons(url): 
    dialog = xbmcgui.Dialog()
    print '############################################################        ADD 7 ICONS          ###############################################################'
    if dialog.yesno("BDTV TEAM","" , "Add 7 Icons Or Restore To 5",'','Restore 5','Add 7'):
        GA("Maintenance","Add 7 Icons")
        url = base+'tweaks/confluence_7.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, 'confluence_7.zip')
        DownloaderClass(url,lib)
        time.sleep(3)
        addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))
        ADDON.setSetting('add7','false')
        dialog = xbmcgui.Dialog()
        dialog.ok("BDTV TEAM", "Please Reboot To Take", "Effect   Brought To You By BDTBOX.BLOGSPOT.CA   ALLfree.TV")
    else:
        GA("Maintenance","Restore 5")
        confluence = xbmc.translatePath(os.path.join('special://home/addons','skin.confluence'))
        if ADDON.getSetting('add7')=='false':
            dialog = xbmcgui.Dialog()
            dialog.ok("BDTV TEAM", "Run Me Again After Reboot To Completely Clean", "Brought To You By www.ALLfree.TV or fb.com/AFTbox")
            ADDON.setSetting('add7','true')
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok("BDTV TEAM", "Great You Are Completely Clean Now", "Brought To You By www.ALLfree.TV or fb.com/AFTbox")
            ADDON.setSetting('add7','false')
        for root, dirs, files in os.walk(confluence):
            try:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            except:
                pass
        try:
            os.rmdir(confluence)
        except:
            pass
            
################################
###       Home Icons         ###
################################    
def SELECT(): dialog=xbmcgui.Dialog(); version_select=['Videos','Music','Program','Picture']; select=['Videos','Music','Programs','Pictures']; return version_select[xbmcgui.Dialog().select('Please Choose Your Build',select)]
def HOMEICONS(url):
    gui_path=xbmc.translatePath(os.path.join('special://home','userdata')); gui=os.path.join(gui_path,'guisettings.xml'); guixml=open(gui, 'r').read(); button=SELECT(); r="skin.confluence.Home%sButton(.+?)"%button; match=re.compile(r).findall(guixml)
    for number in match: addDir(button+' Button '+number,'url',121,'','','')
def HOMEICONS2(name):
    print name
    if   'Video' in name:   r="Skin.SetAddon(Home%s,xbmc.addon.video,xbmc.addon.executable)"%name.replace(' ','')
    elif 'Music' in name:   r="Skin.SetAddon(Home%s,xbmc.addon.audio,xbmc.addon.executable)"%name.replace(' ','')
    elif 'Picture' in name: r="Skin.SetAddon(Home%s,xbmc.addon.image,xbmc.addon.executable)"%name.replace(' ','')
    elif 'Program' in name: r="Skin.SetAddon(Home%s,xbmc.addon.executable)"%name.replace(' ','')
    xbmc.executebuiltin(r); dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Homescreen Shortcut Updated Successfully")
################################
###      End Home Icons      ###
################################

############################################################       WALLPAPER         ###############################################################    
def wallpaper(name,url,iconimage):
    link=OPEN_URL(wallurl)
    match=re.compile('<a href="(.+?)" title=".+?">(.+?)</a>  <small>(.+?)</small').findall(link)
    for url,name,amount in match:
            url=wallurl+url
            name= name+' '+amount
            addDir(name,url,45,iconimage,base+'images/fanart/gettingstarted.jpg','')
    

def wallpaper2(name,url,iconimage):
    link=OPEN_URL(url)
    match=re.compile('href="(.+?)" title=".+?"><p align="center">(.+?)</p>').findall(link)
    if not match:
            wallpaper3(name,url,iconimage)
    elif len(match)<2:
            addDir(name,url,46,iconimage,base+'images/fanart/gettingstarted.jpg','')
    else:
        for url,name in match:
            url=wallurl+url
            addDir(name,url,46,iconimage,base+'images/fanart/gettingstarted.jpg','')


def wallpaper3(name,url,iconimage):    
    link=OPEN_URL(url)
    match=re.compile('href="(.+?)" title=".+?">\n.+?img src="(.+?)" alt="(.+?) HD Wide').findall(link)
    for url,iconimage,name in match:
            url=wallurl+url
            addDir(name,url,47,iconimage,base+'images/fanart/gettingstarted.jpg','')
    if 'Next ' in link:
        try:
	        link=link.split('Previous<')[1]
	        link=link.split('>Next')[0]
	        match=re.compile('href="(.+?)"').findall(link)
	        pos=int(len(match))-1
	        url=wallurl+str(match[pos])
	        name= 'Next Page >>'
	        addDir(name,url,46,base+'images/nextpage.jpg',base+'images/fanart/gettingstarted.jpg','')
        except:
	        pass
    setView('movies', 'MAIN')

def wallpaper_download(name,url,iconimage):  
    GA('Wallpaper','Download '+name)
    link=OPEN_URL(url)
    if ADDON.getSetting('download_wallpaper')=='':
        dialog = xbmcgui.Dialog()
        dialog.ok("BDTV TEAM", "A New Window Will Now Open For You To In Put", "Download Path")
        ADDON.openSettings()
    size='1920x1080'
    r='<a target="_self" href="(.+?)" title=".+?">%s</a>'%(size)
    match=re.compile(r).findall(link)
    url= wallurl+match[0] 
    path = xbmc.translatePath(os.path.join(ADDON.getSetting('download_wallpaper'),''))
    img=os.path.join(path, name+'.jpg')
    try:
        DownloaderClass(url,img, True)    
    except Exception as e:
        try:
            os.remove(img)
        except:
            pass
        if str(e) == "Canceled":
            #you will end up here only if the user cancelled the download 
            pass
    
def hd_wallpaper(name,url,iconimage):
    link=OPEN_URL(hd_wallurl)
    match=re.compile('li style="padding-left:0px;"><a  href="(.+?)">(.+?)</a>').findall(link)
    for url,name in match:    
            url=hd_wallurl+url
            name= name
            addDir(name,url,42,iconimage,base+'images/fanart/gettingstarted.jpg','')
    

def hd_wallpaper2(name,url,iconimage):
    url=url.replace('pageSub','page')
    print'######################## '+url
    link=OPEN_URL(url)
    split=link.split('class="rss-image"')[1]
    match=re.compile('href="(.+?)"><p>(.+?)</p><em>.+?</em><img src="(.+?)"').findall(split)
    for url,name,iconimage in match:
        url=hd_wallurl+'/wallpapers/'+iconimage.replace('/thumbs/','').replace('-t1','-1920x1080')
        addDir(name,url,43,hd_wallurl+iconimage,base+'images/fanart/gettingstarted.jpg','')
    if 'Next ' in link:
        try:
	        if '/pageSub/' in link:
	            link=link.split('Previous<')[2]
	        else:
	            link=link.split('Previous<')[1]
	        link=link.split('>Next')[0]
	        match=re.compile('href="(.+?)"').findall(link)
	        pos=int(len(match))-1
	        url=hd_wallurl+str(match[pos])
	        name= 'Next Page >>'
	        addDir(name,url,42,base+'images/nextpage.jpg',base+'images/fanart/gettingstarted.jpg','')
        except:
	        pass
    setView('movies', 'MAIN')

def hd_wallpaper_download(name,url,iconimage):   
    GA('Wallpaper','Download '+name)
    link=OPEN_URL(url)
    if ADDON.getSetting('download_wallpaper')=='':
        dialog = xbmcgui.Dialog()
        dialog.ok("BDTV TEAM", "A New Window Will Now Open For You To In Put", "Download Path")
        ADDON.openSettings()
    print '==================================    '+url
    path = xbmc.translatePath(os.path.join(ADDON.getSetting('download_wallpaper'),''))
    img=os.path.join(path, name+'.jpg')
    print '==================================    '+img
    try:    
        DownloaderClass(url,img)
    except:    
        DownloaderClass(url.replace('1920x1080','1280x720'),img)
    
def parseDate(dateString):
    try:
        return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except:
        return datetime.datetime.today() - datetime.timedelta(days = 1) #force update


def checkGA():

    secsInHour = 60 * 60
    threshold  = 2 * secsInHour

    now   = datetime.datetime.today()
    prev  = parseDate(ADDON.getSetting('ga_time'))
    delta = now - prev
    nDays = delta.days
    nSecs = delta.seconds

    doUpdate = (nDays > 0) or (nSecs > threshold)
    if not doUpdate:
        return

    ADDON.setSetting('ga_time', str(now).split('.')[0])
    APP_LAUNCH()
    
def send_request_to_google_analytics(utm_url):
    ua='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    import urllib2
    try:
        req = urllib2.Request(utm_url, None,
                                    {'User-Agent':ua}
                                     )
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)         
    return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VISITOR = ADDON.getSetting('visitor_ga')
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
        except:
            print "================  CANNOT POST TO ANALYTICS  ================" 



def APP_LAUNCH():
        versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
        if versionNumber < 12:
            if xbmc.getCondVisibility('system.platform.osx'):
                if xbmc.getCondVisibility('system.platform.atv2'):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
            elif xbmc.getCondVisibility('system.platform.ios'):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility('system.platform.windows'):
                log_path = xbmc.translatePath('special://home')
                log = os.path.join(log_path, 'xbmc.log')
                logfile = open(log, 'r').read()
            elif xbmc.getCondVisibility('system.platform.linux'):
                log_path = xbmc.translatePath('special://home/temp')
            else:
                log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        elif versionNumber > 11:
            print '======================= more than ===================='
            log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'kodi.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        else:
            logfile='Starting XBMC (Unknown Git:.+?Platform: Unknown. Built.+?'
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        print '==========================   '+PATH+' '+VERSION+'  =========================='
        try:
            from hashlib import md5
        except:
            from md5 import md5
        from random import randint
        import time
        from urllib import unquote, quote
        from os import environ
        from hashlib import sha1
        import platform
        VISITOR = ADDON.getSetting('visitor_ga')
        for build, PLATFORM in match:
            if re.search('12',build[0:2],re.IGNORECASE): 
                build="Frodo" 
            if re.search('11',build[0:2],re.IGNORECASE): 
                build="Eden" 
            if re.search('13',build[0:2],re.IGNORECASE): 
                build="Gotham" 
            print build
            print PLATFORM
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + VERSION + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except:
                print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================" 
                
class HUB( xbmcgui.WindowXMLDialog ): # The call MUST be below the xbmcplugin.endOfDirectory(int(sys.argv[1])) or the dialog box will be visible over the pop-up.
    def __init__( self, *args, **kwargs ):
        self.shut = kwargs['close_time'] 
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        xbmc.executebuiltin( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
                                       
    def onInit( self ):
        xbmc.Player().play('%s/resources/skins/DefaultSkin/media/bdtv.mp3'%ADDON.getAddonInfo('path'))# Music.
        while self.shut > 0:
            xbmc.sleep(1000)
            self.shut -= 1
        xbmc.Player().stop()
        self._close_dialog()
                
    def onFocus( self, controlID ): pass
    
    def onClick( self, controlID ): 
        if controlID==12:
            xbmc.Player().stop()
            self._close_dialog()

    def onAction( self, action ):
        if action in [ 5, 6, 7, 9, 10, 92, 117 ] or action.getButtonCode() in [ 275, 257, 261 ]:
            xbmc.Player().stop()
            self._close_dialog()

    def _close_dialog( self ):
        xbmc.executebuiltin( "Skin.Reset(AnimeWindowXMLDialogClose)" )
        time.sleep( .4 )
        self.close()

             
def pop():# Added Close_time for window auto-close length.....
    if xbmc.getCondVisibility('system.platform.ios'):
        if not xbmc.getCondVisibility('system.platform.atv'):
            popup = HUB('hub1.xml',ADDON.getAddonInfo('path'),'DefaultSkin',close_time=34,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%ADDON.getAddonInfo('path'))
    elif xbmc.getCondVisibility('system.platform.android'):
        popup = HUB('hub1.xml',ADDON.getAddonInfo('path'),'DefaultSkin',close_time=34,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%ADDON.getAddonInfo('path'))
    else:
        popup = HUB('hub.xml',ADDON.getAddonInfo('path'),'DefaultSkin',close_time=34,logo_path='%s/resources/skins/DefaultSkin/media/Logo/'%ADDON.getAddonInfo('path'))
    
    popup.doModal()
    del popup
                
def checkdate(dateString):
    try:
        return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except:
        return datetime.datetime.today() - datetime.timedelta(days = 1000) #force update


def check_popup():

    threshold  = 120

    now   = datetime.datetime.today()
    prev  = checkdate(ADDON.getSetting('pop_time'))
    delta = now - prev
    nDays = delta.days

    doUpdate = (nDays > threshold)
    if not doUpdate:
        return

    ADDON.setSetting('pop_time', str(now).split('.')[0])
    pop()
     

checkGA()
             
def addDir(name,url,mode,iconimage,fanart,description):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
def addLink(name,url,iconimage,description,fanart):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty("Fanart_Image",fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok 
        
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
                
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        DeleteCrashLogs(url)
elif mode==2:
        DeletePackages(url)
elif mode==3:
        deletecachefiles(url)
elif mode==4:
        desizone(url)
elif mode==5:
        advancexml(url,name)
elif mode==6:
        joystick(url)
elif mode==7:
        print ""+url +iconimage
        malformed(url)
elif mode==8:
        onechanneldb(url)
elif mode==9:
        maintenance(url)
elif mode==10:
        fixesdir(url)
elif mode==11:
        tweaksdir(url)
elif mode==12:
        lib(url)
elif mode==13:
        howtos(url,fanart)
elif mode==14:
        deleteadvancexml(url)
elif mode==15:
        addon.LogUploader()
elif mode==16:
        fastcoloreden(url,iconimage)
elif mode==17:
        downloadanything(url,name)
elif mode==18:
        BDTVInstaller(url)
elif mode==19:
        atv2channe1fix(url)
elif mode==20:
        onechannelerror(url)
elif mode==21:
        bdtvboxrepo(url)
elif mode==22:
        removemikey(url)
elif mode==23:
        restore(url)
elif mode==24:
        captcha(url)
elif mode==25:
        findaddon(url,name)
elif mode==26:
        removeanything(url)
elif mode==27:
        subtitle(url)
elif mode==28:
        gui(url)
elif mode==29:
        checkadvancexml(url,name)
elif mode==30:
        atv2desifix(url)
elif mode==31:
        onechanneldown(url)
elif mode==33:
        print ""+url +iconimage
        linux_image(url,name,iconimage)
elif mode==34:
        print ""+url +iconimage
        install_linux_image(name,url,iconimage)
elif mode==36:
        findaddondata(url,name)
elif mode==37:
        print ""+url +iconimage
        linux_imageBK(url,name,iconimage)
elif mode==38:
        print ""+url +iconimage
        install_linux_imageBK(name,url,iconimage)
elif mode==39:
        canadapack(url)
elif mode==42:
        hd_wallpaper2(name,url,iconimage)
elif mode==43:
        hd_wallpaper_download(name,url,iconimage)
elif mode==44:
        wallpaper(name,url,iconimage)
elif mode==45:
        wallpaper2(name,url,iconimage)
elif mode==46:
        wallpaper3(name,url,iconimage)
elif mode==47:
        wallpaper_download(name,url,iconimage)
elif mode==48:
        wallpaper_catergories()
elif mode==49:
        hd_wallpaper(name,url,iconimage)
elif mode==50:
        print ""+url +iconimage
        addoninstallpatch(url)
elif mode==51:
        print ""+url +iconimage
        sportscustom(name,url,iconimage)
elif mode==52:
        print ""+url +iconimage
        sportsmain(url)
elif mode==53:
        print ""+url +iconimage
        categorylist(url)
elif mode==54:
        print ""+url +iconimage
        geounlock(url)
elif mode==55:
        print ""+url +iconimage
        deletegeo(url)
elif mode==56:
        print ""+url +iconimage
        DMadulton(name)
elif mode==57:
        print ""+url +iconimage
        DMadultoff(name)
elif mode==60:
        print ""+url +iconimage
        remotes(url)
elif mode==61:
        print ""+url +iconimage
        remoteRM301(name)
elif mode==62:
        print ""+url +iconimage
        remoteXM(name)
elif mode==63:
        print ""+url +iconimage
        srp1003(name)
elif mode==64:
        print ""+url +iconimage
        RCRN04GR(name)
elif mode==65:
        print ""+url +iconimage
        srp2003(name)
elif mode==66:
        print ""+url +iconimage
        jp505(name)
elif mode==67:
        print ""+url +iconimage
        addkeyboardxml(name)
elif mode==68:
        print ""+url +iconimage
        andKB(name)
elif mode==70:
        print ""+url +iconimage
        livelist(name,url,iconimage)
elif mode==100:
        removeICONtexture(name,url,iconimage)
elif mode==101:
        installadult(url)
elif mode==102:
        removeadult(url)
elif mode==111:
        deleteThumbnails()
elif mode==112:
        PIVOSgui()
elif mode==113:
        m1gui()
elif mode==114:
        m3gui()
elif mode==120:
        HOMEICONS(url)
elif mode==121:
        HOMEICONS2(name)
elif mode==500:
        print ""+url +iconimage
        linuxXm3(url)
elif mode==504:
        removeSDdata(name,url,iconimage)
elif mode==505:
        print ""+url +iconimage
        downloadapps(name,url,iconimage)
elif mode==506:
        restoreapps(name,url,iconimage)
elif mode==508:
        print ""+url +iconimage
        copy_addon_setup(name,url,iconimage)
elif mode==509:
        doRecovery(url)
elif mode==600:
        screenfix(url)
elif mode==900:
        bdtvsetup(url)
elif mode==901:
        symlinksetup(name,url,iconimage)
elif mode==902:
        reboot(url)
elif mode==903:
        print ""+url +iconimage
        copy_live_list(name,url,iconimage)
elif mode==904:
        copy_sp_list(name,url,iconimage)
elif mode==905:
        delspcustom(url)
elif mode==906:
        intialsetup(name,url,iconimage)
elif mode==907:
        m1setup()
elif mode==908:
        m3setup()
elif mode==1000:
        worldlive(url)
elif mode==1001:
        AndSETUP()
elif mode==1002:
        customPlugin(name,url,iconimage)
elif mode==1003:
        inflate(url)
elif mode==1004:
        ROOTinflate(url)
elif mode==1005:
        non64Play(url,name)
elif mode==1006:
        showPIC(url)
elif mode==1007:
        showSLIDE(url)
elif mode==1008:
        runexe(url)


		
elif mode==1035:
        BDTVapk_update(url,name,iconimage)
elif mode==1036:
#        print ""+url +iconimage
        BDTVapk_install(name,url,iconimage)
elif mode==1037:
#        print ""+url +iconimage
        apk_load(url,name,iconimage)
elif mode==1038:
#        print ""+url +iconimage
        apk_install(name,url,iconimage)
elif mode==1039:
#        print ""+url +iconimage
        genesisfix(url)
elif mode==1040:
#        print ""+url +iconimage
        factoryDATA(name,url,iconimage)

        
elif mode==2000:
        pop()
        GA('None','Need Help')

elif mode==111:
        import maintenance
        maintenance.doMaintenance(1)
        GA("Maintenance","Delete Thumbnails")
        dialog = xbmcgui.Dialog()
        dialog.ok("BDTV TEAM", "All Done Thank You", "Brought To You By fb.com/AFTbox")

xbmcplugin.endOfDirectory(int(sys.argv[1]))
check_popup()